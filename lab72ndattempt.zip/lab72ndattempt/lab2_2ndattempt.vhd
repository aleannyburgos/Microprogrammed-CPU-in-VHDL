library ieee; use ieee.std_logic_1164.all;
library lpm; use lpm.lpm_components.all;

entity lab2_2ndattempt is
port (clk, clear, z: in std_logic;
	useqEnOut: out std_logic;
	pcSeg1, pcSeg2: out std_logic_vector(0 to 6);
	r0SegHi, r0SegLo, r1SegHi, r1SegLo: out std_logic_vector(0 to 6);
	spSeg1, spSeg2: out std_logic_vector(0 to 6);
	ctrlSignals: out std_logic_vector(0 to 22));
end lab2_2ndattempt;

architecture structural of lab2_2ndattempt is
-- add component declaration of f25lab7_useq

component f25lab7_useq
generic (uROM_width: positive := 32; -- uROM width
			uROM_file : string := ""); -- uROM file path
port (opcode: in std_logic_vector(3 downto 0);
	uop: out std_logic_vector(1 to (uROM_width-9));
	debug_map_addr: out std_logic_vector(8 downto 0); -- for debugging
	enable, clear, clock: in std_logic);
end component;

component segment_decoder
port (c: in std_logic_vector(3 downto 0);
		segments: out std_logic_vector(0 to 6)
	);
end component;

signal useqEnable, useqClear: std_logic;
signal uop : std_logic_vector(1 to 23);

--microops/control signals
signal pc_Load, pc_inc, pc_Clear, mar_load, mdr_load, memWE, sp_load, sp_inc_dec, sp_inc_dec_en, ir_load, x_load, z_load, jump : std_logic;

signal pc_out, mar_out, mdr_out, mem_out, sp_out, ir_out, r0_out, r1_out, not_r0_out, not_r1_out,z_out, x_out, not_x_out: std_logic_vector(7 downto 0);

signal pcout0, pcout1, spout0, spout1, r0_out1, r0_out0, r1_out1, r1_out0 : std_logic_vector(3 downto 0);

signal r0_enable, r1_enable, add_sub,pc_enable : std_logic;
signal R01_cond : std_logic;

signal mar_mux_out, mdr_mux_out, r_mux_out, x_mux_out,z_mux_out, r0_mux_out, r1_mux_out, r0_add_sub_out, r1_add_sub_out: std_logic_vector(7 downto 0);

signal mar_mux_sel,r0_mux_sel, r1_mux_sel : std_logic_vector(1 downto 0);
signal mdr_mux_sel, x_mux_sel, z_mux_sel: std_logic;
signal ram_data : std_logic_vector(7 downto 0);

signal z_bit : std_logic;



begin
	delay: lpm_counter generic map(lpm_width=>2) port map(clock=>clk, cout=>useqEnable);
	useqClear <= clear;
	useqEnOut <= useqEnable;
	labelG: for i in 0 to 22 generate
		ctrlSignals(i) <= uop(i+1) and useqEnable;
	end generate;


	pc_clear <= uop(1) and useqEnable;
	pc_inc   <= uop(2) and useqEnable;
	pc_load  <= uop(3) and useqEnable;
	mdr_load <= uop(4) and useqEnable;
	mdr_mux_sel <= uop(5);
	mar_load <= uop(6) and useqEnable;
	mar_mux_sel <= uop(7) & uop(8);
	memWE   <= uop(9) and useqEnable;
	ir_load <= uop(10) and useqEnable;
	sp_load <= uop(11) and useqEnable;
	sp_inc_dec <= uop(12);
	sp_inc_dec_en <= uop(13) and useqEnable;
	add_sub <= uop(14);
	r0_mux_sel <= uop(15) & uop(16);
	r1_mux_sel <= uop(17) & uop(18);
	r01_cond <= uop(19) and useqEnable;
	jump <= uop(20);
	z_mux_sel <= uop(21);
	x_load <= uop(22) and useqEnable;
	z_load <= uop(23) and useqEnable;

	z_bit <= z_out(0);
	
	--enables
	r0_enable <= R01_cond and not IR_out(0);
	r1_enable <= R01_cond and  IR_out(0);
	pc_enable <= (pc_load and not jump) or (jump and z_bit);

	not_r1_out <= not r1_out;
	not_r0_out <= not r0_out;
	
	not_x_out <= not x_out;

	
-- add port map statement of f25lab7_useq, use the uROm Test file in the next slide
-- add pc register, seven-segment display
-- add mar, mdr registers and ram, seven-segment displays

	usequencer :f25lab7_useq
		generic map (uROM_file => "./myurom.mif",  uROM_width => 32)
		port map (enable => useqEnable, clear => useqClear, clock => clk, opcode => ir_out(7 downto 4), uop => uop);
	
	pc_counter : lpm_counter
		generic map (lpm_width => 8)
		port map (clock => clk, q => pc_Out, cnt_en => pc_Inc, data => mdr_out, sload => pc_enable, sclr => pc_Clear);
	
	mar_reg : lpm_ff
		generic map(LPM_width => 8)
		port map(data => mar_mux_out, enable => mar_load, q => mar_out, clock => clk);
		
	ram_data <= mdr_out when memWE = '1' else (others => 'Z');
	Ram : lpm_ram_dq
		generic map(lpm_width => 8,lpm_widthad => 8, lpm_file => "lab7_ram01.mif")
		port map (address => mar_out, data => ram_data, we => memWE, q => mem_out, outclock => clk, inclock => clk);
	
	mdr_reg : lpm_ff
		generic map(LPM_width => 8)
		port map(data => mdr_mux_out, enable => mdr_load, q => mdr_out, clock => clk);
		
	sp_counter : lpm_counter
		generic map (lpm_width => 8)
		port map (clock => clk, q => sp_out, cnt_en => sp_inc_dec_en, data => mdr_out, sload => sp_load, updown => sp_inc_dec);
		
	ir_reg : lpm_ff
		generic map(LPM_width => 8)
		port map(data => mdr_out, enable => ir_load, q => ir_out, clock => clk);
		
	r0_reg : lpm_ff
		generic map(LPM_width => 8)
		port map(data => r0_mux_out, enable => r0_enable, q => r0_out, clock => clk);	
		
	r1_reg : lpm_ff
		generic map(LPM_width => 8)
		port map(data => r1_mux_out, enable => r1_enable, q => r1_out, clock => clk);
		
	x_reg : lpm_ff
		generic map(LPM_width => 8)
		port map(data => x_mux_out, enable => x_load, q => x_out, clock => clk);
		
	z_reg : lpm_ff
		generic map(LPM_width => 8)
		port map(data => z_mux_out, enable => z_load, q => z_out, clock => clk);
		

		-- MAR mux (3:1)
	with mar_mux_sel select
	  mar_mux_out <= sp_out  when "00",
						  pc_out  when "01",
						  mdr_out when "10",
						  (others => '0') when others;

	with ir_out(0) select
	  r_mux_out <= r0_out when '0',
						r1_out when others;

	with mdr_mux_sel select
	  mdr_mux_out <= mem_out   when '1',
						  r_mux_out when '0',
						  r_mux_out when others;


	with r0_mux_sel select
	  r0_mux_out <= mdr_out        when "00",
						 r1_out         when "01",
						 r0_add_sub_out when "10",
						 (others => '0') when others;

	with r1_mux_sel select
	  r1_mux_out <= mdr_out        when "00",
						 r0_out         when "01",
						 r1_add_sub_out when "10",
						 (others => '0') when others;

	with x_mux_sel select
	  x_mux_out <= not_r0_out when '0',
						not_r1_out when others;

	with z_mux_sel select
	  z_mux_out <= x_out when '0',
						not_x_out when others;

						
	r0add : lpm_add_sub
		generic map (LPM_width => 8)
		port map (dataa => r0_out, datab => r1_out, add_sub => add_sub, result => r0_add_sub_out);

	r1add : lpm_add_sub
		generic map (LPM_width => 8)
		port map (dataa => r1_out, datab => r0_out, add_sub => add_sub, result => r1_add_sub_out);

	pcout0 <= pc_out(3 downto 0);
	pcout1 <= pc_out(7 downto 4);
	
	spout0 <= sp_out(3 downto 0);
	spout1 <= sp_out(7 downto 4);	
	
	r1_out0 <= r1_out (3 downto 0);
	r1_out1 <= r1_out (7 downto 4);
	
	r0_out0 <= r0_out (3 downto 0);
	r0_out1 <= r0_out (7 downto 4);
	
	--segments
	pcseg_0 : segment_decoder
				port map (c => pcout0, segments => pcSeg1);
	pcseg_1 : segment_decoder
				port map (c => pcout1, segments => pcSeg2);
	r1seg_0 : segment_decoder
				port map (c => r1_out0, segments => r1seglo);
	r1seg_1 : segment_decoder
				port map (c => r1_out1, segments => r1seghi);
	r0seg_0 : segment_decoder
				port map (c => r0_out0, segments => r0seglo);
	r0seg_1 : segment_decoder	
				port map (c => r0_out1, segments => r0seghi);
	spseg_0 : segment_decoder
				port map (c => pcout0, segments => spSeg1);
	spseg_1 : segment_decoder
				port map (c => pcout1, segments => spSeg2);
				
end structural;