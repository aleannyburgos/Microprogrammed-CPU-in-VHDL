transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vcom -93 -work work {C:/Users/alean/OneDrive/Desktop/Fall 2025/ECE495/lab7/lab72ndattempt/f25lab7_useq.vhd}
vcom -93 -work work {C:/Users/alean/OneDrive/Desktop/Fall 2025/ECE495/lab7/lab72ndattempt/lab2_2ndattempt.vhd}
vcom -93 -work work {C:/Users/alean/OneDrive/Desktop/Fall 2025/ECE495/lab7/lab72ndattempt/segment_decoder.vhd}

