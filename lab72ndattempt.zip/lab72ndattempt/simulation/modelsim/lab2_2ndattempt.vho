-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "12/18/2025 18:52:57"

-- 
-- Device: Altera EP4CE115F29C7 Package FBGA780
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIVE;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIVE.CYCLONEIVE_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	lab2_2ndattempt IS
    PORT (
	clk : IN std_logic;
	clear : IN std_logic;
	z : IN std_logic;
	useqEnOut : BUFFER std_logic;
	pcSeg1 : BUFFER std_logic_vector(0 TO 6);
	pcSeg2 : BUFFER std_logic_vector(0 TO 6);
	r0SegHi : BUFFER std_logic_vector(0 TO 6);
	r0SegLo : BUFFER std_logic_vector(0 TO 6);
	r1SegHi : BUFFER std_logic_vector(0 TO 6);
	r1SegLo : BUFFER std_logic_vector(0 TO 6);
	spSeg1 : BUFFER std_logic_vector(0 TO 6);
	spSeg2 : BUFFER std_logic_vector(0 TO 6);
	ctrlSignals : BUFFER std_logic_vector(0 TO 22)
	);
END lab2_2ndattempt;

-- Design Ports Information
-- z	=>  Location: PIN_AH23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- useqEnOut	=>  Location: PIN_E25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pcSeg1[6]	=>  Location: PIN_B25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pcSeg1[5]	=>  Location: PIN_C25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pcSeg1[4]	=>  Location: PIN_D23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pcSeg1[3]	=>  Location: PIN_A26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pcSeg1[2]	=>  Location: PIN_C21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pcSeg1[1]	=>  Location: PIN_A12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pcSeg1[0]	=>  Location: PIN_B23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pcSeg2[6]	=>  Location: PIN_B11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pcSeg2[5]	=>  Location: PIN_H14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pcSeg2[4]	=>  Location: PIN_D12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pcSeg2[3]	=>  Location: PIN_E14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pcSeg2[2]	=>  Location: PIN_D21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pcSeg2[1]	=>  Location: PIN_A10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- pcSeg2[0]	=>  Location: PIN_J13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r0SegHi[6]	=>  Location: PIN_B18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r0SegHi[5]	=>  Location: PIN_C17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r0SegHi[4]	=>  Location: PIN_D17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r0SegHi[3]	=>  Location: PIN_D19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r0SegHi[2]	=>  Location: PIN_C24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r0SegHi[1]	=>  Location: PIN_G21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r0SegHi[0]	=>  Location: PIN_E17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r0SegLo[6]	=>  Location: PIN_H17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r0SegLo[5]	=>  Location: PIN_H21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r0SegLo[4]	=>  Location: PIN_H16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r0SegLo[3]	=>  Location: PIN_G22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r0SegLo[2]	=>  Location: PIN_J16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r0SegLo[1]	=>  Location: PIN_J17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r0SegLo[0]	=>  Location: PIN_C13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r1SegHi[6]	=>  Location: PIN_G18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r1SegHi[5]	=>  Location: PIN_F17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r1SegHi[4]	=>  Location: PIN_G19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r1SegHi[3]	=>  Location: PIN_G20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r1SegHi[2]	=>  Location: PIN_A17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r1SegHi[1]	=>  Location: PIN_G15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r1SegHi[0]	=>  Location: PIN_J19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r1SegLo[6]	=>  Location: PIN_C14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r1SegLo[5]	=>  Location: PIN_E15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r1SegLo[4]	=>  Location: PIN_H19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r1SegLo[3]	=>  Location: PIN_D16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r1SegLo[2]	=>  Location: PIN_C16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r1SegLo[1]	=>  Location: PIN_D15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r1SegLo[0]	=>  Location: PIN_C15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- spSeg1[6]	=>  Location: PIN_E21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- spSeg1[5]	=>  Location: PIN_D25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- spSeg1[4]	=>  Location: PIN_E19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- spSeg1[3]	=>  Location: PIN_A25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- spSeg1[2]	=>  Location: PIN_F19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- spSeg1[1]	=>  Location: PIN_D14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- spSeg1[0]	=>  Location: PIN_A23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- spSeg2[6]	=>  Location: PIN_A11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- spSeg2[5]	=>  Location: PIN_J14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- spSeg2[4]	=>  Location: PIN_C12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- spSeg2[3]	=>  Location: PIN_F14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- spSeg2[2]	=>  Location: PIN_C22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- spSeg2[1]	=>  Location: PIN_B10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- spSeg2[0]	=>  Location: PIN_J12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[22]	=>  Location: PIN_A19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[21]	=>  Location: PIN_F18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[20]	=>  Location: PIN_C19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[19]	=>  Location: PIN_C20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[18]	=>  Location: PIN_F15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[17]	=>  Location: PIN_D13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[16]	=>  Location: PIN_G16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[15]	=>  Location: PIN_H15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[14]	=>  Location: PIN_J15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[13]	=>  Location: PIN_C18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[12]	=>  Location: PIN_E24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[11]	=>  Location: PIN_B21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[10]	=>  Location: PIN_D20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[9]	=>  Location: PIN_B19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[8]	=>  Location: PIN_D18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[7]	=>  Location: PIN_B22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[6]	=>  Location: PIN_A22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[5]	=>  Location: PIN_A18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[4]	=>  Location: PIN_A21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[3]	=>  Location: PIN_D24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[2]	=>  Location: PIN_B17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[1]	=>  Location: PIN_C23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ctrlSignals[0]	=>  Location: PIN_G17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk	=>  Location: PIN_J1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clear	=>  Location: PIN_E18,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF lab2_2ndattempt IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk : std_logic;
SIGNAL ww_clear : std_logic;
SIGNAL ww_z : std_logic;
SIGNAL ww_useqEnOut : std_logic;
SIGNAL ww_pcSeg1 : std_logic_vector(0 TO 6);
SIGNAL ww_pcSeg2 : std_logic_vector(0 TO 6);
SIGNAL ww_r0SegHi : std_logic_vector(0 TO 6);
SIGNAL ww_r0SegLo : std_logic_vector(0 TO 6);
SIGNAL ww_r1SegHi : std_logic_vector(0 TO 6);
SIGNAL ww_r1SegLo : std_logic_vector(0 TO 6);
SIGNAL ww_spSeg1 : std_logic_vector(0 TO 6);
SIGNAL ww_spSeg2 : std_logic_vector(0 TO 6);
SIGNAL ww_ctrlSignals : std_logic_vector(0 TO 22);
SIGNAL \Ram|sram|ram_block|auto_generated|ram_block1a0_PORTADATAIN_bus\ : std_logic_vector(17 DOWNTO 0);
SIGNAL \Ram|sram|ram_block|auto_generated|ram_block1a0_PORTAADDR_bus\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \Ram|sram|ram_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\ : std_logic_vector(17 DOWNTO 0);
SIGNAL \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTAADDR_bus\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\ : std_logic_vector(35 DOWNTO 0);
SIGNAL \clk~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \z~input_o\ : std_logic;
SIGNAL \useqEnOut~output_o\ : std_logic;
SIGNAL \pcSeg1[6]~output_o\ : std_logic;
SIGNAL \pcSeg1[5]~output_o\ : std_logic;
SIGNAL \pcSeg1[4]~output_o\ : std_logic;
SIGNAL \pcSeg1[3]~output_o\ : std_logic;
SIGNAL \pcSeg1[2]~output_o\ : std_logic;
SIGNAL \pcSeg1[1]~output_o\ : std_logic;
SIGNAL \pcSeg1[0]~output_o\ : std_logic;
SIGNAL \pcSeg2[6]~output_o\ : std_logic;
SIGNAL \pcSeg2[5]~output_o\ : std_logic;
SIGNAL \pcSeg2[4]~output_o\ : std_logic;
SIGNAL \pcSeg2[3]~output_o\ : std_logic;
SIGNAL \pcSeg2[2]~output_o\ : std_logic;
SIGNAL \pcSeg2[1]~output_o\ : std_logic;
SIGNAL \pcSeg2[0]~output_o\ : std_logic;
SIGNAL \r0SegHi[6]~output_o\ : std_logic;
SIGNAL \r0SegHi[5]~output_o\ : std_logic;
SIGNAL \r0SegHi[4]~output_o\ : std_logic;
SIGNAL \r0SegHi[3]~output_o\ : std_logic;
SIGNAL \r0SegHi[2]~output_o\ : std_logic;
SIGNAL \r0SegHi[1]~output_o\ : std_logic;
SIGNAL \r0SegHi[0]~output_o\ : std_logic;
SIGNAL \r0SegLo[6]~output_o\ : std_logic;
SIGNAL \r0SegLo[5]~output_o\ : std_logic;
SIGNAL \r0SegLo[4]~output_o\ : std_logic;
SIGNAL \r0SegLo[3]~output_o\ : std_logic;
SIGNAL \r0SegLo[2]~output_o\ : std_logic;
SIGNAL \r0SegLo[1]~output_o\ : std_logic;
SIGNAL \r0SegLo[0]~output_o\ : std_logic;
SIGNAL \r1SegHi[6]~output_o\ : std_logic;
SIGNAL \r1SegHi[5]~output_o\ : std_logic;
SIGNAL \r1SegHi[4]~output_o\ : std_logic;
SIGNAL \r1SegHi[3]~output_o\ : std_logic;
SIGNAL \r1SegHi[2]~output_o\ : std_logic;
SIGNAL \r1SegHi[1]~output_o\ : std_logic;
SIGNAL \r1SegHi[0]~output_o\ : std_logic;
SIGNAL \r1SegLo[6]~output_o\ : std_logic;
SIGNAL \r1SegLo[5]~output_o\ : std_logic;
SIGNAL \r1SegLo[4]~output_o\ : std_logic;
SIGNAL \r1SegLo[3]~output_o\ : std_logic;
SIGNAL \r1SegLo[2]~output_o\ : std_logic;
SIGNAL \r1SegLo[1]~output_o\ : std_logic;
SIGNAL \r1SegLo[0]~output_o\ : std_logic;
SIGNAL \spSeg1[6]~output_o\ : std_logic;
SIGNAL \spSeg1[5]~output_o\ : std_logic;
SIGNAL \spSeg1[4]~output_o\ : std_logic;
SIGNAL \spSeg1[3]~output_o\ : std_logic;
SIGNAL \spSeg1[2]~output_o\ : std_logic;
SIGNAL \spSeg1[1]~output_o\ : std_logic;
SIGNAL \spSeg1[0]~output_o\ : std_logic;
SIGNAL \spSeg2[6]~output_o\ : std_logic;
SIGNAL \spSeg2[5]~output_o\ : std_logic;
SIGNAL \spSeg2[4]~output_o\ : std_logic;
SIGNAL \spSeg2[3]~output_o\ : std_logic;
SIGNAL \spSeg2[2]~output_o\ : std_logic;
SIGNAL \spSeg2[1]~output_o\ : std_logic;
SIGNAL \spSeg2[0]~output_o\ : std_logic;
SIGNAL \ctrlSignals[22]~output_o\ : std_logic;
SIGNAL \ctrlSignals[21]~output_o\ : std_logic;
SIGNAL \ctrlSignals[20]~output_o\ : std_logic;
SIGNAL \ctrlSignals[19]~output_o\ : std_logic;
SIGNAL \ctrlSignals[18]~output_o\ : std_logic;
SIGNAL \ctrlSignals[17]~output_o\ : std_logic;
SIGNAL \ctrlSignals[16]~output_o\ : std_logic;
SIGNAL \ctrlSignals[15]~output_o\ : std_logic;
SIGNAL \ctrlSignals[14]~output_o\ : std_logic;
SIGNAL \ctrlSignals[13]~output_o\ : std_logic;
SIGNAL \ctrlSignals[12]~output_o\ : std_logic;
SIGNAL \ctrlSignals[11]~output_o\ : std_logic;
SIGNAL \ctrlSignals[10]~output_o\ : std_logic;
SIGNAL \ctrlSignals[9]~output_o\ : std_logic;
SIGNAL \ctrlSignals[8]~output_o\ : std_logic;
SIGNAL \ctrlSignals[7]~output_o\ : std_logic;
SIGNAL \ctrlSignals[6]~output_o\ : std_logic;
SIGNAL \ctrlSignals[5]~output_o\ : std_logic;
SIGNAL \ctrlSignals[4]~output_o\ : std_logic;
SIGNAL \ctrlSignals[3]~output_o\ : std_logic;
SIGNAL \ctrlSignals[2]~output_o\ : std_logic;
SIGNAL \ctrlSignals[1]~output_o\ : std_logic;
SIGNAL \ctrlSignals[0]~output_o\ : std_logic;
SIGNAL \clk~input_o\ : std_logic;
SIGNAL \clk~inputclkctrl_outclk\ : std_logic;
SIGNAL \delay|auto_generated|counter_comb_bita0~combout\ : std_logic;
SIGNAL \delay|auto_generated|counter_comb_bita0~COUT\ : std_logic;
SIGNAL \delay|auto_generated|counter_comb_bita1~combout\ : std_logic;
SIGNAL \delay|auto_generated|counter_comb_bita1~COUT\ : std_logic;
SIGNAL \delay|auto_generated|counter_comb_bita1~0_combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_comb_bita0~combout\ : std_logic;
SIGNAL \r0add|auto_generated|_~7_combout\ : std_logic;
SIGNAL \r1add|auto_generated|_~0_combout\ : std_logic;
SIGNAL \r0add|auto_generated|_~2_combout\ : std_logic;
SIGNAL \r1add|auto_generated|_~3_combout\ : std_logic;
SIGNAL \r0add|auto_generated|_~4_combout\ : std_logic;
SIGNAL \r0_reg|dffs[0]~9_cout\ : std_logic;
SIGNAL \r0_reg|dffs[0]~10_combout\ : std_logic;
SIGNAL \ir_reg|dffs[0]~feeder_combout\ : std_logic;
SIGNAL \ctrlSignals~13_combout\ : std_logic;
SIGNAL \mdr_reg|dffs[0]~0_combout\ : std_logic;
SIGNAL \ctrlSignals~14_combout\ : std_logic;
SIGNAL \sp_counter|auto_generated|counter_comb_bita0~combout\ : std_logic;
SIGNAL \ctrlSignals~12_combout\ : std_logic;
SIGNAL \sp_counter|auto_generated|_~0_combout\ : std_logic;
SIGNAL \mar_reg|dffs[0]~0_combout\ : std_logic;
SIGNAL \mar_reg|dffs[7]~8_combout\ : std_logic;
SIGNAL \ctrlSignals~17_combout\ : std_logic;
SIGNAL \sp_counter|auto_generated|counter_comb_bita0~COUT\ : std_logic;
SIGNAL \sp_counter|auto_generated|counter_comb_bita1~combout\ : std_logic;
SIGNAL \mdr_reg|dffs[1]~1_combout\ : std_logic;
SIGNAL \sp_counter|auto_generated|counter_comb_bita1~COUT\ : std_logic;
SIGNAL \sp_counter|auto_generated|counter_comb_bita2~combout\ : std_logic;
SIGNAL \mdr_reg|dffs[2]~2_combout\ : std_logic;
SIGNAL \sp_counter|auto_generated|counter_comb_bita2~COUT\ : std_logic;
SIGNAL \sp_counter|auto_generated|counter_comb_bita3~combout\ : std_logic;
SIGNAL \mdr_reg|dffs[3]~3_combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_comb_bita0~COUT\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_comb_bita1~combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_reg_bit[1]~4_combout\ : std_logic;
SIGNAL \x_reg|dffs[0]~0_combout\ : std_logic;
SIGNAL \ctrlSignals~1_combout\ : std_logic;
SIGNAL \z_mux_out[0]~0_combout\ : std_logic;
SIGNAL \ctrlSignals~0_combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_reg_bit[7]~1_combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_reg_bit[7]~2_combout\ : std_logic;
SIGNAL \ctrlSignals~21_combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_reg_bit[7]~3_combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|_~0_combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_comb_bita1~COUT\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_comb_bita2~combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_reg_bit[2]~5_combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_comb_bita2~COUT\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_comb_bita3~combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_reg_bit[3]~6_combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_comb_bita3~COUT\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_comb_bita4~combout\ : std_logic;
SIGNAL \mdr_reg|dffs[4]~4_combout\ : std_logic;
SIGNAL \sp_counter|auto_generated|counter_comb_bita3~COUT\ : std_logic;
SIGNAL \sp_counter|auto_generated|counter_comb_bita4~combout\ : std_logic;
SIGNAL \sp_counter|auto_generated|counter_comb_bita4~COUT\ : std_logic;
SIGNAL \sp_counter|auto_generated|counter_comb_bita5~combout\ : std_logic;
SIGNAL \mdr_reg|dffs[5]~5_combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_comb_bita4~COUT\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_comb_bita5~combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_reg_bit[5]~8_combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_comb_bita5~COUT\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_comb_bita6~combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_reg_bit[6]~9_combout\ : std_logic;
SIGNAL \sp_counter|auto_generated|counter_comb_bita5~COUT\ : std_logic;
SIGNAL \sp_counter|auto_generated|counter_comb_bita6~combout\ : std_logic;
SIGNAL \mar_reg|dffs[6]~6_combout\ : std_logic;
SIGNAL \sp_counter|auto_generated|counter_comb_bita6~COUT\ : std_logic;
SIGNAL \sp_counter|auto_generated|counter_comb_bita7~combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_comb_bita6~COUT\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_comb_bita7~combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_reg_bit[7]~10_combout\ : std_logic;
SIGNAL \mar_reg|dffs[7]~7_combout\ : std_logic;
SIGNAL \ctrlSignals~19_combout\ : std_logic;
SIGNAL \mar_reg|dffs[5]~5_combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_reg_bit[4]~7_combout\ : std_logic;
SIGNAL \mar_reg|dffs[4]~4_combout\ : std_logic;
SIGNAL \mar_reg|dffs[3]~3_combout\ : std_logic;
SIGNAL \mar_reg|dffs[2]~2_combout\ : std_logic;
SIGNAL \mar_reg|dffs[1]~1_combout\ : std_logic;
SIGNAL \Mux15~0_combout\ : std_logic;
SIGNAL \r0_reg|dffs[7]~20_combout\ : std_logic;
SIGNAL \r0_enable~combout\ : std_logic;
SIGNAL \r1add|auto_generated|_~4_combout\ : std_logic;
SIGNAL \r1_reg|dffs[0]~9_cout\ : std_logic;
SIGNAL \r1_reg|dffs[0]~10_combout\ : std_logic;
SIGNAL \Mux23~0_combout\ : std_logic;
SIGNAL \r1_reg|dffs[7]~20_combout\ : std_logic;
SIGNAL \r1_enable~combout\ : std_logic;
SIGNAL \r1_reg|dffs[0]~11\ : std_logic;
SIGNAL \r1_reg|dffs[1]~12_combout\ : std_logic;
SIGNAL \Mux22~0_combout\ : std_logic;
SIGNAL \r0add|auto_generated|_~3_combout\ : std_logic;
SIGNAL \r0_reg|dffs[0]~11\ : std_logic;
SIGNAL \r0_reg|dffs[1]~12_combout\ : std_logic;
SIGNAL \Mux14~0_combout\ : std_logic;
SIGNAL \r0_reg|dffs[1]~13\ : std_logic;
SIGNAL \r0_reg|dffs[2]~14_combout\ : std_logic;
SIGNAL \Mux13~0_combout\ : std_logic;
SIGNAL \r1add|auto_generated|_~2_combout\ : std_logic;
SIGNAL \r1_reg|dffs[1]~13\ : std_logic;
SIGNAL \r1_reg|dffs[2]~14_combout\ : std_logic;
SIGNAL \Mux21~0_combout\ : std_logic;
SIGNAL \r1_reg|dffs[2]~15\ : std_logic;
SIGNAL \r1_reg|dffs[3]~16_combout\ : std_logic;
SIGNAL \Mux20~0_combout\ : std_logic;
SIGNAL \r0add|auto_generated|_~1_combout\ : std_logic;
SIGNAL \r0_reg|dffs[2]~15\ : std_logic;
SIGNAL \r0_reg|dffs[3]~16_combout\ : std_logic;
SIGNAL \Mux12~0_combout\ : std_logic;
SIGNAL \r1add|auto_generated|_~1_combout\ : std_logic;
SIGNAL \r1_reg|dffs[3]~17\ : std_logic;
SIGNAL \r1_reg|dffs[4]~18_combout\ : std_logic;
SIGNAL \Mux19~0_combout\ : std_logic;
SIGNAL \r0add|auto_generated|_~0_combout\ : std_logic;
SIGNAL \r0_reg|dffs[3]~17\ : std_logic;
SIGNAL \r0_reg|dffs[4]~18_combout\ : std_logic;
SIGNAL \Mux11~0_combout\ : std_logic;
SIGNAL \r0_reg|dffs[4]~19\ : std_logic;
SIGNAL \r0_reg|dffs[5]~21_combout\ : std_logic;
SIGNAL \Mux10~0_combout\ : std_logic;
SIGNAL \r1add|auto_generated|_~5_combout\ : std_logic;
SIGNAL \r1_reg|dffs[4]~19\ : std_logic;
SIGNAL \r1_reg|dffs[5]~21_combout\ : std_logic;
SIGNAL \Mux18~0_combout\ : std_logic;
SIGNAL \r0add|auto_generated|_~5_combout\ : std_logic;
SIGNAL \r0_reg|dffs[5]~22\ : std_logic;
SIGNAL \r0_reg|dffs[6]~24\ : std_logic;
SIGNAL \r0_reg|dffs[7]~25_combout\ : std_logic;
SIGNAL \Mux8~0_combout\ : std_logic;
SIGNAL \r1add|auto_generated|_~7_combout\ : std_logic;
SIGNAL \r1_reg|dffs[5]~22\ : std_logic;
SIGNAL \r1_reg|dffs[6]~24\ : std_logic;
SIGNAL \r1_reg|dffs[7]~25_combout\ : std_logic;
SIGNAL \Mux16~0_combout\ : std_logic;
SIGNAL \mdr_reg|dffs[7]~7_combout\ : std_logic;
SIGNAL \ir_reg|dffs[7]~feeder_combout\ : std_logic;
SIGNAL \usequencer|uPC_mux|auto_generated|result_node[7]~7_combout\ : std_logic;
SIGNAL \clear~input_o\ : std_logic;
SIGNAL \r0add|auto_generated|_~6_combout\ : std_logic;
SIGNAL \r0_reg|dffs[6]~23_combout\ : std_logic;
SIGNAL \Mux9~0_combout\ : std_logic;
SIGNAL \r1add|auto_generated|_~6_combout\ : std_logic;
SIGNAL \r1_reg|dffs[6]~23_combout\ : std_logic;
SIGNAL \Mux17~0_combout\ : std_logic;
SIGNAL \mdr_reg|dffs[6]~6_combout\ : std_logic;
SIGNAL \usequencer|uPC_mux|auto_generated|result_node[6]~6_combout\ : std_logic;
SIGNAL \usequencer|uPC_mux|auto_generated|result_node[5]~5_combout\ : std_logic;
SIGNAL \usequencer|uPC_mux|auto_generated|result_node[4]~4_combout\ : std_logic;
SIGNAL \usequencer|uPC_mux|auto_generated|result_node[3]~3_combout\ : std_logic;
SIGNAL \usequencer|uPC_mux|auto_generated|result_node[2]~2_combout\ : std_logic;
SIGNAL \usequencer|uPC_mux|auto_generated|result_node[1]~1_combout\ : std_logic;
SIGNAL \usequencer|uPC_mux|auto_generated|result_node[0]~0_combout\ : std_logic;
SIGNAL \pc_counter|auto_generated|counter_reg_bit[0]~0_combout\ : std_logic;
SIGNAL \pcseg_0|Mux6~0_combout\ : std_logic;
SIGNAL \pcseg_0|Mux5~0_combout\ : std_logic;
SIGNAL \pcseg_0|Mux4~0_combout\ : std_logic;
SIGNAL \pcseg_0|Mux3~0_combout\ : std_logic;
SIGNAL \pcseg_0|Mux2~0_combout\ : std_logic;
SIGNAL \pcseg_0|Mux1~0_combout\ : std_logic;
SIGNAL \pcseg_0|Mux0~0_combout\ : std_logic;
SIGNAL \pcseg_1|Mux6~0_combout\ : std_logic;
SIGNAL \pcseg_1|Mux5~0_combout\ : std_logic;
SIGNAL \pcseg_1|Mux4~0_combout\ : std_logic;
SIGNAL \pcseg_1|Mux3~0_combout\ : std_logic;
SIGNAL \pcseg_1|Mux2~0_combout\ : std_logic;
SIGNAL \pcseg_1|Mux1~0_combout\ : std_logic;
SIGNAL \pcseg_1|Mux0~0_combout\ : std_logic;
SIGNAL \r0seg_1|Mux6~0_combout\ : std_logic;
SIGNAL \r0seg_1|Mux5~0_combout\ : std_logic;
SIGNAL \r0seg_1|Mux4~0_combout\ : std_logic;
SIGNAL \r0seg_1|Mux3~0_combout\ : std_logic;
SIGNAL \r0seg_1|Mux2~0_combout\ : std_logic;
SIGNAL \r0seg_1|Mux1~0_combout\ : std_logic;
SIGNAL \r0seg_1|Mux0~0_combout\ : std_logic;
SIGNAL \r0seg_0|Mux6~0_combout\ : std_logic;
SIGNAL \r0seg_0|Mux5~0_combout\ : std_logic;
SIGNAL \r0seg_0|Mux4~0_combout\ : std_logic;
SIGNAL \r0seg_0|Mux3~0_combout\ : std_logic;
SIGNAL \r0seg_0|Mux2~0_combout\ : std_logic;
SIGNAL \r0seg_0|Mux1~0_combout\ : std_logic;
SIGNAL \r0seg_0|Mux0~0_combout\ : std_logic;
SIGNAL \r1seg_1|Mux6~0_combout\ : std_logic;
SIGNAL \r1seg_1|Mux5~0_combout\ : std_logic;
SIGNAL \r1seg_1|Mux4~0_combout\ : std_logic;
SIGNAL \r1seg_1|Mux3~0_combout\ : std_logic;
SIGNAL \r1seg_1|Mux2~0_combout\ : std_logic;
SIGNAL \r1seg_1|Mux1~0_combout\ : std_logic;
SIGNAL \r1seg_1|Mux0~0_combout\ : std_logic;
SIGNAL \r1seg_0|Mux6~0_combout\ : std_logic;
SIGNAL \r1seg_0|Mux5~0_combout\ : std_logic;
SIGNAL \r1seg_0|Mux4~0_combout\ : std_logic;
SIGNAL \r1seg_0|Mux3~0_combout\ : std_logic;
SIGNAL \r1seg_0|Mux2~0_combout\ : std_logic;
SIGNAL \r1seg_0|Mux1~0_combout\ : std_logic;
SIGNAL \r1seg_0|Mux0~0_combout\ : std_logic;
SIGNAL \ctrlSignals~2_combout\ : std_logic;
SIGNAL \ctrlSignals~3_combout\ : std_logic;
SIGNAL \ctrlSignals~4_combout\ : std_logic;
SIGNAL \ctrlSignals~5_combout\ : std_logic;
SIGNAL \ctrlSignals~6_combout\ : std_logic;
SIGNAL \ctrlSignals~7_combout\ : std_logic;
SIGNAL \ctrlSignals~8_combout\ : std_logic;
SIGNAL \ctrlSignals~9_combout\ : std_logic;
SIGNAL \ctrlSignals~10_combout\ : std_logic;
SIGNAL \ctrlSignals~11_combout\ : std_logic;
SIGNAL \ctrlSignals~15_combout\ : std_logic;
SIGNAL \ctrlSignals~16_combout\ : std_logic;
SIGNAL \ctrlSignals~18_combout\ : std_logic;
SIGNAL \ctrlSignals~20_combout\ : std_logic;
SIGNAL \ctrlSignals~22_combout\ : std_logic;
SIGNAL \mdr_reg|dffs\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \r0_reg|dffs\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \r1_reg|dffs\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \x_reg|dffs\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \delay|auto_generated|counter_reg_bit\ : std_logic_vector(1 DOWNTO 0);
SIGNAL \ir_reg|dffs\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \sp_counter|auto_generated|counter_reg_bit\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \Ram|sram|ram_block|auto_generated|q_a\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \mar_reg|dffs\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \usequencer|uPC|dffs\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \usequencer|uROM|srom|rom_block|auto_generated|q_a\ : std_logic_vector(31 DOWNTO 0);
SIGNAL \z_reg|dffs\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \pc_counter|auto_generated|counter_reg_bit\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \r0seg_1|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \pcseg_1|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \pcseg_0|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\ : std_logic_vector(17 DOWNTO 15);
SIGNAL \r1seg_0|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \r1seg_1|ALT_INV_Mux6~0_combout\ : std_logic;
SIGNAL \r0seg_0|ALT_INV_Mux6~0_combout\ : std_logic;

BEGIN

ww_clk <= clk;
ww_clear <= clear;
ww_z <= z;
useqEnOut <= ww_useqEnOut;
pcSeg1 <= ww_pcSeg1;
pcSeg2 <= ww_pcSeg2;
r0SegHi <= ww_r0SegHi;
r0SegLo <= ww_r0SegLo;
r1SegHi <= ww_r1SegHi;
r1SegLo <= ww_r1SegLo;
spSeg1 <= ww_spSeg1;
spSeg2 <= ww_spSeg2;
ctrlSignals <= ww_ctrlSignals;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\Ram|sram|ram_block|auto_generated|ram_block1a0_PORTADATAIN_bus\ <= (gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & \mdr_reg|dffs\(7) & \mdr_reg|dffs\(6) & \mdr_reg|dffs\(5) & \mdr_reg|dffs\(4) & \mdr_reg|dffs\(3) & 
\mdr_reg|dffs\(2) & \mdr_reg|dffs\(1) & \mdr_reg|dffs\(0));

\Ram|sram|ram_block|auto_generated|ram_block1a0_PORTAADDR_bus\ <= (\mar_reg|dffs\(7) & \mar_reg|dffs\(6) & \mar_reg|dffs\(5) & \mar_reg|dffs\(4) & \mar_reg|dffs\(3) & \mar_reg|dffs\(2) & \mar_reg|dffs\(1) & \mar_reg|dffs\(0));

\Ram|sram|ram_block|auto_generated|q_a\(0) <= \Ram|sram|ram_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(0);
\Ram|sram|ram_block|auto_generated|q_a\(1) <= \Ram|sram|ram_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(1);
\Ram|sram|ram_block|auto_generated|q_a\(2) <= \Ram|sram|ram_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(2);
\Ram|sram|ram_block|auto_generated|q_a\(3) <= \Ram|sram|ram_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(3);
\Ram|sram|ram_block|auto_generated|q_a\(4) <= \Ram|sram|ram_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(4);
\Ram|sram|ram_block|auto_generated|q_a\(5) <= \Ram|sram|ram_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(5);
\Ram|sram|ram_block|auto_generated|q_a\(6) <= \Ram|sram|ram_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(6);
\Ram|sram|ram_block|auto_generated|q_a\(7) <= \Ram|sram|ram_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(7);

\usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTAADDR_bus\ <= (\usequencer|uPC|dffs\(7) & \usequencer|uPC|dffs\(6) & \usequencer|uPC|dffs\(5) & \usequencer|uPC|dffs\(4) & \usequencer|uPC|dffs\(3) & \usequencer|uPC|dffs\(2) & 
\usequencer|uPC|dffs\(1) & \usequencer|uPC|dffs\(0));

\usequencer|uROM|srom|rom_block|auto_generated|q_a\(0) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(0);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(1) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(1);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(2) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(2);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(3) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(3);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(4) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(4);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(5) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(5);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(6) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(6);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(7) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(7);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(8) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(8);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(9) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(9);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(10) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(10);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(11) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(11);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(12) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(12);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(13) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(13);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(14);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(15) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(15);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(16);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(17) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(17);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(18) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(18);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(19) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(19);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(20);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(21) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(21);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(22) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(22);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(23) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(23);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(24);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(25) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(25);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(26) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(26);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(27) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(27);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(28) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(28);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(29) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(29);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(30) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(30);
\usequencer|uROM|srom|rom_block|auto_generated|q_a\(31) <= \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\(31);

\clk~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk~input_o\);
\r0seg_1|ALT_INV_Mux6~0_combout\ <= NOT \r0seg_1|Mux6~0_combout\;
\pcseg_1|ALT_INV_Mux6~0_combout\ <= NOT \pcseg_1|Mux6~0_combout\;
\pcseg_0|ALT_INV_Mux6~0_combout\ <= NOT \pcseg_0|Mux6~0_combout\;
\usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(15) <= NOT \usequencer|uROM|srom|rom_block|auto_generated|q_a\(15);
\usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(17) <= NOT \usequencer|uROM|srom|rom_block|auto_generated|q_a\(17);
\r1seg_0|ALT_INV_Mux6~0_combout\ <= NOT \r1seg_0|Mux6~0_combout\;
\r1seg_1|ALT_INV_Mux6~0_combout\ <= NOT \r1seg_1|Mux6~0_combout\;
\r0seg_0|ALT_INV_Mux6~0_combout\ <= NOT \r0seg_0|Mux6~0_combout\;

-- Location: IOOBUF_X83_Y73_N2
\useqEnOut~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \delay|auto_generated|counter_comb_bita1~0_combout\,
	devoe => ww_devoe,
	o => \useqEnOut~output_o\);

-- Location: IOOBUF_X107_Y73_N2
\pcSeg1[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_0|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \pcSeg1[6]~output_o\);

-- Location: IOOBUF_X105_Y73_N9
\pcSeg1[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_0|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \pcSeg1[5]~output_o\);

-- Location: IOOBUF_X100_Y73_N16
\pcSeg1[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_0|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \pcSeg1[4]~output_o\);

-- Location: IOOBUF_X109_Y73_N2
\pcSeg1[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_0|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \pcSeg1[3]~output_o\);

-- Location: IOOBUF_X91_Y73_N16
\pcSeg1[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_0|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \pcSeg1[2]~output_o\);

-- Location: IOOBUF_X47_Y73_N2
\pcSeg1[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_0|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \pcSeg1[1]~output_o\);

-- Location: IOOBUF_X102_Y73_N9
\pcSeg1[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_0|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \pcSeg1[0]~output_o\);

-- Location: IOOBUF_X42_Y73_N9
\pcSeg2[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_1|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \pcSeg2[6]~output_o\);

-- Location: IOOBUF_X49_Y73_N16
\pcSeg2[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_1|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \pcSeg2[5]~output_o\);

-- Location: IOOBUF_X52_Y73_N23
\pcSeg2[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_1|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \pcSeg2[4]~output_o\);

-- Location: IOOBUF_X45_Y73_N9
\pcSeg2[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_1|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \pcSeg2[3]~output_o\);

-- Location: IOOBUF_X96_Y73_N23
\pcSeg2[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_1|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \pcSeg2[2]~output_o\);

-- Location: IOOBUF_X38_Y73_N2
\pcSeg2[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_1|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \pcSeg2[1]~output_o\);

-- Location: IOOBUF_X40_Y73_N2
\pcSeg2[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_1|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \pcSeg2[0]~output_o\);

-- Location: IOOBUF_X79_Y73_N9
\r0SegHi[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r0seg_1|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \r0SegHi[6]~output_o\);

-- Location: IOOBUF_X81_Y73_N2
\r0SegHi[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r0seg_1|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \r0SegHi[5]~output_o\);

-- Location: IOOBUF_X81_Y73_N9
\r0SegHi[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r0seg_1|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \r0SegHi[4]~output_o\);

-- Location: IOOBUF_X83_Y73_N16
\r0SegHi[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r0seg_1|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \r0SegHi[3]~output_o\);

-- Location: IOOBUF_X98_Y73_N16
\r0SegHi[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r0seg_1|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \r0SegHi[2]~output_o\);

-- Location: IOOBUF_X74_Y73_N23
\r0SegHi[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r0seg_1|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \r0SegHi[1]~output_o\);

-- Location: IOOBUF_X67_Y73_N23
\r0SegHi[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r0seg_1|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \r0SegHi[0]~output_o\);

-- Location: IOOBUF_X67_Y73_N9
\r0SegLo[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r0seg_0|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \r0SegLo[6]~output_o\);

-- Location: IOOBUF_X72_Y73_N16
\r0SegLo[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r0seg_0|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \r0SegLo[5]~output_o\);

-- Location: IOOBUF_X65_Y73_N23
\r0SegLo[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r0seg_0|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \r0SegLo[4]~output_o\);

-- Location: IOOBUF_X72_Y73_N23
\r0SegLo[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r0seg_0|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \r0SegLo[3]~output_o\);

-- Location: IOOBUF_X65_Y73_N16
\r0SegLo[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r0seg_0|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \r0SegLo[2]~output_o\);

-- Location: IOOBUF_X69_Y73_N2
\r0SegLo[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r0seg_0|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \r0SegLo[1]~output_o\);

-- Location: IOOBUF_X54_Y73_N2
\r0SegLo[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r0seg_0|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \r0SegLo[0]~output_o\);

-- Location: IOOBUF_X69_Y73_N23
\r1SegHi[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r1seg_1|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \r1SegHi[6]~output_o\);

-- Location: IOOBUF_X67_Y73_N16
\r1SegHi[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r1seg_1|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \r1SegHi[5]~output_o\);

-- Location: IOOBUF_X69_Y73_N16
\r1SegHi[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r1seg_1|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \r1SegHi[4]~output_o\);

-- Location: IOOBUF_X74_Y73_N16
\r1SegHi[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r1seg_1|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \r1SegHi[3]~output_o\);

-- Location: IOOBUF_X60_Y73_N2
\r1SegHi[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r1seg_1|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \r1SegHi[2]~output_o\);

-- Location: IOOBUF_X65_Y73_N9
\r1SegHi[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r1seg_1|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \r1SegHi[1]~output_o\);

-- Location: IOOBUF_X72_Y73_N9
\r1SegHi[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r1seg_1|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \r1SegHi[0]~output_o\);

-- Location: IOOBUF_X52_Y73_N2
\r1SegLo[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r1seg_0|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \r1SegLo[6]~output_o\);

-- Location: IOOBUF_X58_Y73_N9
\r1SegLo[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r1seg_0|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \r1SegLo[5]~output_o\);

-- Location: IOOBUF_X72_Y73_N2
\r1SegLo[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r1seg_0|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \r1SegLo[4]~output_o\);

-- Location: IOOBUF_X62_Y73_N23
\r1SegLo[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r1seg_0|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \r1SegLo[3]~output_o\);

-- Location: IOOBUF_X62_Y73_N16
\r1SegLo[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r1seg_0|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \r1SegLo[2]~output_o\);

-- Location: IOOBUF_X58_Y73_N23
\r1SegLo[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r1seg_0|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \r1SegLo[1]~output_o\);

-- Location: IOOBUF_X58_Y73_N16
\r1SegLo[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \r1seg_0|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \r1SegLo[0]~output_o\);

-- Location: IOOBUF_X107_Y73_N9
\spSeg1[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_0|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \spSeg1[6]~output_o\);

-- Location: IOOBUF_X105_Y73_N2
\spSeg1[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_0|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \spSeg1[5]~output_o\);

-- Location: IOOBUF_X94_Y73_N9
\spSeg1[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_0|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \spSeg1[4]~output_o\);

-- Location: IOOBUF_X109_Y73_N9
\spSeg1[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_0|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \spSeg1[3]~output_o\);

-- Location: IOOBUF_X94_Y73_N2
\spSeg1[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_0|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \spSeg1[2]~output_o\);

-- Location: IOOBUF_X52_Y73_N9
\spSeg1[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_0|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \spSeg1[1]~output_o\);

-- Location: IOOBUF_X102_Y73_N2
\spSeg1[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_0|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \spSeg1[0]~output_o\);

-- Location: IOOBUF_X42_Y73_N2
\spSeg2[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_1|ALT_INV_Mux6~0_combout\,
	devoe => ww_devoe,
	o => \spSeg2[6]~output_o\);

-- Location: IOOBUF_X49_Y73_N23
\spSeg2[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_1|Mux5~0_combout\,
	devoe => ww_devoe,
	o => \spSeg2[5]~output_o\);

-- Location: IOOBUF_X52_Y73_N16
\spSeg2[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_1|Mux4~0_combout\,
	devoe => ww_devoe,
	o => \spSeg2[4]~output_o\);

-- Location: IOOBUF_X45_Y73_N2
\spSeg2[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_1|Mux3~0_combout\,
	devoe => ww_devoe,
	o => \spSeg2[3]~output_o\);

-- Location: IOOBUF_X96_Y73_N16
\spSeg2[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_1|Mux2~0_combout\,
	devoe => ww_devoe,
	o => \spSeg2[2]~output_o\);

-- Location: IOOBUF_X38_Y73_N9
\spSeg2[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_1|Mux1~0_combout\,
	devoe => ww_devoe,
	o => \spSeg2[1]~output_o\);

-- Location: IOOBUF_X40_Y73_N9
\spSeg2[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \pcseg_1|Mux0~0_combout\,
	devoe => ww_devoe,
	o => \spSeg2[0]~output_o\);

-- Location: IOOBUF_X81_Y73_N16
\ctrlSignals[22]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~0_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[22]~output_o\);

-- Location: IOOBUF_X87_Y73_N16
\ctrlSignals[21]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~1_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[21]~output_o\);

-- Location: IOOBUF_X83_Y73_N9
\ctrlSignals[20]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~2_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[20]~output_o\);

-- Location: IOOBUF_X85_Y73_N9
\ctrlSignals[19]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~3_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[19]~output_o\);

-- Location: IOOBUF_X58_Y73_N2
\ctrlSignals[18]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~4_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[18]~output_o\);

-- Location: IOOBUF_X54_Y73_N9
\ctrlSignals[17]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~5_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[17]~output_o\);

-- Location: IOOBUF_X67_Y73_N2
\ctrlSignals[16]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~6_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[16]~output_o\);

-- Location: IOOBUF_X60_Y73_N16
\ctrlSignals[15]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~7_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[15]~output_o\);

-- Location: IOOBUF_X60_Y73_N23
\ctrlSignals[14]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~8_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[14]~output_o\);

-- Location: IOOBUF_X87_Y73_N23
\ctrlSignals[13]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~9_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[13]~output_o\);

-- Location: IOOBUF_X85_Y73_N23
\ctrlSignals[12]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~10_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[12]~output_o\);

-- Location: IOOBUF_X87_Y73_N2
\ctrlSignals[11]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~11_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[11]~output_o\);

-- Location: IOOBUF_X85_Y73_N16
\ctrlSignals[10]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~12_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[10]~output_o\);

-- Location: IOOBUF_X81_Y73_N23
\ctrlSignals[9]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~13_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[9]~output_o\);

-- Location: IOOBUF_X85_Y73_N2
\ctrlSignals[8]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~14_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[8]~output_o\);

-- Location: IOOBUF_X89_Y73_N16
\ctrlSignals[7]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~15_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[7]~output_o\);

-- Location: IOOBUF_X89_Y73_N9
\ctrlSignals[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~16_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[6]~output_o\);

-- Location: IOOBUF_X79_Y73_N2
\ctrlSignals[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~17_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[5]~output_o\);

-- Location: IOOBUF_X89_Y73_N23
\ctrlSignals[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~18_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[4]~output_o\);

-- Location: IOOBUF_X98_Y73_N23
\ctrlSignals[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~19_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[3]~output_o\);

-- Location: IOOBUF_X60_Y73_N9
\ctrlSignals[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~20_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[2]~output_o\);

-- Location: IOOBUF_X100_Y73_N23
\ctrlSignals[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~21_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[1]~output_o\);

-- Location: IOOBUF_X83_Y73_N23
\ctrlSignals[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ctrlSignals~22_combout\,
	devoe => ww_devoe,
	o => \ctrlSignals[0]~output_o\);

-- Location: IOIBUF_X0_Y36_N8
\clk~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk,
	o => \clk~input_o\);

-- Location: CLKCTRL_G2
\clk~inputclkctrl\ : cycloneive_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk~inputclkctrl_outclk\);

-- Location: LCCOMB_X75_Y66_N6
\delay|auto_generated|counter_comb_bita0\ : cycloneive_lcell_comb
-- Equation(s):
-- \delay|auto_generated|counter_comb_bita0~combout\ = \delay|auto_generated|counter_reg_bit\(0) $ (VCC)
-- \delay|auto_generated|counter_comb_bita0~COUT\ = CARRY(\delay|auto_generated|counter_reg_bit\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \delay|auto_generated|counter_reg_bit\(0),
	datad => VCC,
	combout => \delay|auto_generated|counter_comb_bita0~combout\,
	cout => \delay|auto_generated|counter_comb_bita0~COUT\);

-- Location: FF_X75_Y66_N7
\delay|auto_generated|counter_reg_bit[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \delay|auto_generated|counter_comb_bita0~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \delay|auto_generated|counter_reg_bit\(0));

-- Location: LCCOMB_X75_Y66_N8
\delay|auto_generated|counter_comb_bita1\ : cycloneive_lcell_comb
-- Equation(s):
-- \delay|auto_generated|counter_comb_bita1~combout\ = (\delay|auto_generated|counter_reg_bit\(1) & (!\delay|auto_generated|counter_comb_bita0~COUT\)) # (!\delay|auto_generated|counter_reg_bit\(1) & ((\delay|auto_generated|counter_comb_bita0~COUT\) # (GND)))
-- \delay|auto_generated|counter_comb_bita1~COUT\ = CARRY((!\delay|auto_generated|counter_comb_bita0~COUT\) # (!\delay|auto_generated|counter_reg_bit\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \delay|auto_generated|counter_reg_bit\(1),
	datad => VCC,
	cin => \delay|auto_generated|counter_comb_bita0~COUT\,
	combout => \delay|auto_generated|counter_comb_bita1~combout\,
	cout => \delay|auto_generated|counter_comb_bita1~COUT\);

-- Location: FF_X75_Y66_N9
\delay|auto_generated|counter_reg_bit[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \delay|auto_generated|counter_comb_bita1~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \delay|auto_generated|counter_reg_bit\(1));

-- Location: LCCOMB_X75_Y66_N10
\delay|auto_generated|counter_comb_bita1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \delay|auto_generated|counter_comb_bita1~0_combout\ = !\delay|auto_generated|counter_comb_bita1~COUT\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \delay|auto_generated|counter_comb_bita1~COUT\,
	combout => \delay|auto_generated|counter_comb_bita1~0_combout\);

-- Location: LCCOMB_X76_Y66_N12
\pc_counter|auto_generated|counter_comb_bita0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_comb_bita0~combout\ = \pc_counter|auto_generated|counter_reg_bit\(0) $ (VCC)
-- \pc_counter|auto_generated|counter_comb_bita0~COUT\ = CARRY(\pc_counter|auto_generated|counter_reg_bit\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \pc_counter|auto_generated|counter_reg_bit\(0),
	datad => VCC,
	combout => \pc_counter|auto_generated|counter_comb_bita0~combout\,
	cout => \pc_counter|auto_generated|counter_comb_bita0~COUT\);

-- Location: M9K_X78_Y66_N0
\usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0\ : cycloneive_ram_block
-- pragma translate_off
GENERIC MAP (
	mem_init4 => X"0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000F00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
	mem_init3 => X"020010001800E30180000E20040000E10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008000010100000D30040000D20000800D10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000020010180000C20040000C10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002010010580000B20050000B1000000000000000000000000000000000000000000000000",
	mem_init2 => X"0000000000000000000000000000000000000000000000000000000000000000000000000010010580000A20050000A100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002000000105800009200500009100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000020100000048100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
	mem_init1 => X"0000A0100000047100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002A00100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000006A0010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000160010000000000000000000000000000000000000000000000000000000000000000",
	mem_init0 => X"00000000000000000000000000000000000000800035010000034006000033058000032005000031000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002001018000024006000023058000022005000021000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002001018000014000000013040000012005000011000000000000000000000000000000000000000000000000000000000000000000000000000000000000000101000400006018000005000000004040000003005000002000000001",
	data_interleave_offset_in_bits => 1,
	data_interleave_width_in_bits => 1,
	init_file => "./myurom.mif",
	init_file_layout => "port_a",
	logical_ram_name => "f25lab7_useq:usequencer|lpm_rom:uROM|altrom:srom|altsyncram:rom_block|altsyncram_ca01:auto_generated|ALTSYNCRAM",
	operation_mode => "rom",
	port_a_address_clear => "none",
	port_a_address_width => 8,
	port_a_byte_enable_clock => "none",
	port_a_data_out_clear => "none",
	port_a_data_out_clock => "clock0",
	port_a_data_width => 36,
	port_a_first_address => 0,
	port_a_first_bit_number => 0,
	port_a_last_address => 255,
	port_a_logical_ram_depth => 256,
	port_a_logical_ram_width => 32,
	port_a_read_during_write_mode => "new_data_with_nbe_read",
	port_a_write_enable_clock => "none",
	port_b_address_width => 8,
	port_b_data_width => 36,
	ram_block_type => "M9K")
-- pragma translate_on
PORT MAP (
	portare => VCC,
	clk0 => \clk~inputclkctrl_outclk\,
	clk1 => GND,
	portaaddr => \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTAADDR_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	portadataout => \usequencer|uROM|srom|rom_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\);

-- Location: LCCOMB_X73_Y67_N24
\r0add|auto_generated|_~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0add|auto_generated|_~7_combout\ = \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18) $ (\r1_reg|dffs\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	datad => \r1_reg|dffs\(7),
	combout => \r0add|auto_generated|_~7_combout\);

-- Location: LCCOMB_X73_Y66_N0
\r1add|auto_generated|_~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1add|auto_generated|_~0_combout\ = \r0_reg|dffs\(4) $ (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(18))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \r0_reg|dffs\(4),
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	combout => \r1add|auto_generated|_~0_combout\);

-- Location: LCCOMB_X74_Y67_N28
\r0add|auto_generated|_~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0add|auto_generated|_~2_combout\ = \r1_reg|dffs\(2) $ (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(18))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \r1_reg|dffs\(2),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	combout => \r0add|auto_generated|_~2_combout\);

-- Location: LCCOMB_X73_Y66_N24
\r1add|auto_generated|_~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1add|auto_generated|_~3_combout\ = \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18) $ (\r0_reg|dffs\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	datad => \r0_reg|dffs\(1),
	combout => \r1add|auto_generated|_~3_combout\);

-- Location: LCCOMB_X74_Y67_N2
\r0add|auto_generated|_~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0add|auto_generated|_~4_combout\ = \r1_reg|dffs\(0) $ (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(18))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(0),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	combout => \r0add|auto_generated|_~4_combout\);

-- Location: LCCOMB_X74_Y67_N6
\r0_reg|dffs[0]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0_reg|dffs[0]~9_cout\ = CARRY(!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(18))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	datad => VCC,
	cout => \r0_reg|dffs[0]~9_cout\);

-- Location: LCCOMB_X74_Y67_N8
\r0_reg|dffs[0]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0_reg|dffs[0]~10_combout\ = (\r0_reg|dffs\(0) & ((\r0add|auto_generated|_~4_combout\ & (!\r0_reg|dffs[0]~9_cout\)) # (!\r0add|auto_generated|_~4_combout\ & (\r0_reg|dffs[0]~9_cout\ & VCC)))) # (!\r0_reg|dffs\(0) & ((\r0add|auto_generated|_~4_combout\ & 
-- ((\r0_reg|dffs[0]~9_cout\) # (GND))) # (!\r0add|auto_generated|_~4_combout\ & (!\r0_reg|dffs[0]~9_cout\))))
-- \r0_reg|dffs[0]~11\ = CARRY((\r0_reg|dffs\(0) & (\r0add|auto_generated|_~4_combout\ & !\r0_reg|dffs[0]~9_cout\)) # (!\r0_reg|dffs\(0) & ((\r0add|auto_generated|_~4_combout\) # (!\r0_reg|dffs[0]~9_cout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100101001101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(0),
	datab => \r0add|auto_generated|_~4_combout\,
	datad => VCC,
	cin => \r0_reg|dffs[0]~9_cout\,
	combout => \r0_reg|dffs[0]~10_combout\,
	cout => \r0_reg|dffs[0]~11\);

-- Location: LCCOMB_X75_Y66_N24
\ir_reg|dffs[0]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \ir_reg|dffs[0]~feeder_combout\ = \mdr_reg|dffs\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \mdr_reg|dffs\(0),
	combout => \ir_reg|dffs[0]~feeder_combout\);

-- Location: LCCOMB_X75_Y66_N22
\ctrlSignals~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~13_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(22) & \delay|auto_generated|counter_comb_bita1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(22),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \ctrlSignals~13_combout\);

-- Location: FF_X75_Y66_N25
\ir_reg|dffs[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \ir_reg|dffs[0]~feeder_combout\,
	ena => \ctrlSignals~13_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \ir_reg|dffs\(0));

-- Location: LCCOMB_X75_Y67_N16
\mdr_reg|dffs[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \mdr_reg|dffs[0]~0_combout\ = (\ir_reg|dffs\(0) & (\r1_reg|dffs\(0))) # (!\ir_reg|dffs\(0) & ((\r0_reg|dffs\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(0),
	datab => \r0_reg|dffs\(0),
	datad => \ir_reg|dffs\(0),
	combout => \mdr_reg|dffs[0]~0_combout\);

-- Location: LCCOMB_X79_Y67_N12
\ctrlSignals~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~14_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(23) & \delay|auto_generated|counter_comb_bita1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(23),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \ctrlSignals~14_combout\);

-- Location: LCCOMB_X77_Y66_N10
\sp_counter|auto_generated|counter_comb_bita0\ : cycloneive_lcell_comb
-- Equation(s):
-- \sp_counter|auto_generated|counter_comb_bita0~combout\ = \sp_counter|auto_generated|counter_reg_bit\(0) $ (((VCC) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20))))
-- \sp_counter|auto_generated|counter_comb_bita0~COUT\ = CARRY(\sp_counter|auto_generated|counter_reg_bit\(0) $ (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110011001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \sp_counter|auto_generated|counter_reg_bit\(0),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(20),
	datad => VCC,
	combout => \sp_counter|auto_generated|counter_comb_bita0~combout\,
	cout => \sp_counter|auto_generated|counter_comb_bita0~COUT\);

-- Location: LCCOMB_X77_Y66_N4
\ctrlSignals~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~12_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(21) & \delay|auto_generated|counter_comb_bita1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(21),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \ctrlSignals~12_combout\);

-- Location: LCCOMB_X77_Y66_N26
\sp_counter|auto_generated|_~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \sp_counter|auto_generated|_~0_combout\ = (\delay|auto_generated|counter_comb_bita1~0_combout\ & ((\usequencer|uROM|srom|rom_block|auto_generated|q_a\(21)) # (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(19))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(21),
	datac => \delay|auto_generated|counter_comb_bita1~0_combout\,
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(19),
	combout => \sp_counter|auto_generated|_~0_combout\);

-- Location: FF_X77_Y66_N11
\sp_counter|auto_generated|counter_reg_bit[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \sp_counter|auto_generated|counter_comb_bita0~combout\,
	asdata => \mdr_reg|dffs\(0),
	sload => \ctrlSignals~12_combout\,
	ena => \sp_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \sp_counter|auto_generated|counter_reg_bit\(0));

-- Location: LCCOMB_X76_Y67_N24
\mar_reg|dffs[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \mar_reg|dffs[0]~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & ((\pc_counter|auto_generated|counter_reg_bit\(0)))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & (\sp_counter|auto_generated|counter_reg_bit\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sp_counter|auto_generated|counter_reg_bit\(0),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(24),
	datad => \pc_counter|auto_generated|counter_reg_bit\(0),
	combout => \mar_reg|dffs[0]~0_combout\);

-- Location: LCCOMB_X76_Y67_N10
\mar_reg|dffs[7]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \mar_reg|dffs[7]~8_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(25))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(24),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(25),
	combout => \mar_reg|dffs[7]~8_combout\);

-- Location: LCCOMB_X76_Y67_N28
\ctrlSignals~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~17_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(26) & \delay|auto_generated|counter_comb_bita1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(26),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \ctrlSignals~17_combout\);

-- Location: FF_X76_Y67_N25
\mar_reg|dffs[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mar_reg|dffs[0]~0_combout\,
	asdata => \mdr_reg|dffs\(0),
	sclr => \mar_reg|dffs[7]~8_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(25),
	ena => \ctrlSignals~17_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mar_reg|dffs\(0));

-- Location: LCCOMB_X77_Y66_N12
\sp_counter|auto_generated|counter_comb_bita1\ : cycloneive_lcell_comb
-- Equation(s):
-- \sp_counter|auto_generated|counter_comb_bita1~combout\ = (\sp_counter|auto_generated|counter_comb_bita0~COUT\ & (\sp_counter|auto_generated|counter_reg_bit\(1) $ (((\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20)) # (VCC))))) # 
-- (!\sp_counter|auto_generated|counter_comb_bita0~COUT\ & (((\sp_counter|auto_generated|counter_reg_bit\(1)) # (GND))))
-- \sp_counter|auto_generated|counter_comb_bita1~COUT\ = CARRY((\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20) $ (\sp_counter|auto_generated|counter_reg_bit\(1))) # (!\sp_counter|auto_generated|counter_comb_bita0~COUT\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110001101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(20),
	datab => \sp_counter|auto_generated|counter_reg_bit\(1),
	datad => VCC,
	cin => \sp_counter|auto_generated|counter_comb_bita0~COUT\,
	combout => \sp_counter|auto_generated|counter_comb_bita1~combout\,
	cout => \sp_counter|auto_generated|counter_comb_bita1~COUT\);

-- Location: LCCOMB_X75_Y67_N6
\mdr_reg|dffs[1]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \mdr_reg|dffs[1]~1_combout\ = (\ir_reg|dffs\(0) & ((\r1_reg|dffs\(1)))) # (!\ir_reg|dffs\(0) & (\r0_reg|dffs\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(1),
	datab => \r1_reg|dffs\(1),
	datad => \ir_reg|dffs\(0),
	combout => \mdr_reg|dffs[1]~1_combout\);

-- Location: LCCOMB_X77_Y66_N14
\sp_counter|auto_generated|counter_comb_bita2\ : cycloneive_lcell_comb
-- Equation(s):
-- \sp_counter|auto_generated|counter_comb_bita2~combout\ = (\sp_counter|auto_generated|counter_comb_bita1~COUT\ & (\sp_counter|auto_generated|counter_reg_bit\(2) & ((VCC)))) # (!\sp_counter|auto_generated|counter_comb_bita1~COUT\ & 
-- (\sp_counter|auto_generated|counter_reg_bit\(2) $ (((VCC) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20))))))
-- \sp_counter|auto_generated|counter_comb_bita2~COUT\ = CARRY((!\sp_counter|auto_generated|counter_comb_bita1~COUT\ & (\sp_counter|auto_generated|counter_reg_bit\(2) $ (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \sp_counter|auto_generated|counter_reg_bit\(2),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(20),
	datad => VCC,
	cin => \sp_counter|auto_generated|counter_comb_bita1~COUT\,
	combout => \sp_counter|auto_generated|counter_comb_bita2~combout\,
	cout => \sp_counter|auto_generated|counter_comb_bita2~COUT\);

-- Location: LCCOMB_X75_Y67_N0
\mdr_reg|dffs[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \mdr_reg|dffs[2]~2_combout\ = (\ir_reg|dffs\(0) & ((\r1_reg|dffs\(2)))) # (!\ir_reg|dffs\(0) & (\r0_reg|dffs\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(2),
	datab => \ir_reg|dffs\(0),
	datad => \r1_reg|dffs\(2),
	combout => \mdr_reg|dffs[2]~2_combout\);

-- Location: LCCOMB_X77_Y66_N16
\sp_counter|auto_generated|counter_comb_bita3\ : cycloneive_lcell_comb
-- Equation(s):
-- \sp_counter|auto_generated|counter_comb_bita3~combout\ = (\sp_counter|auto_generated|counter_comb_bita2~COUT\ & (\sp_counter|auto_generated|counter_reg_bit\(3) $ (((\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20)) # (VCC))))) # 
-- (!\sp_counter|auto_generated|counter_comb_bita2~COUT\ & ((\sp_counter|auto_generated|counter_reg_bit\(3)) # ((GND))))
-- \sp_counter|auto_generated|counter_comb_bita3~COUT\ = CARRY((\sp_counter|auto_generated|counter_reg_bit\(3) $ (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20))) # (!\sp_counter|auto_generated|counter_comb_bita2~COUT\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \sp_counter|auto_generated|counter_reg_bit\(3),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(20),
	datad => VCC,
	cin => \sp_counter|auto_generated|counter_comb_bita2~COUT\,
	combout => \sp_counter|auto_generated|counter_comb_bita3~combout\,
	cout => \sp_counter|auto_generated|counter_comb_bita3~COUT\);

-- Location: LCCOMB_X75_Y67_N18
\mdr_reg|dffs[3]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \mdr_reg|dffs[3]~3_combout\ = (\ir_reg|dffs\(0) & ((\r1_reg|dffs\(3)))) # (!\ir_reg|dffs\(0) & (\r0_reg|dffs\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(3),
	datab => \ir_reg|dffs\(0),
	datad => \r1_reg|dffs\(3),
	combout => \mdr_reg|dffs[3]~3_combout\);

-- Location: LCCOMB_X76_Y66_N14
\pc_counter|auto_generated|counter_comb_bita1\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_comb_bita1~combout\ = (\pc_counter|auto_generated|counter_reg_bit\(1) & (!\pc_counter|auto_generated|counter_comb_bita0~COUT\)) # (!\pc_counter|auto_generated|counter_reg_bit\(1) & 
-- ((\pc_counter|auto_generated|counter_comb_bita0~COUT\) # (GND)))
-- \pc_counter|auto_generated|counter_comb_bita1~COUT\ = CARRY((!\pc_counter|auto_generated|counter_comb_bita0~COUT\) # (!\pc_counter|auto_generated|counter_reg_bit\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \pc_counter|auto_generated|counter_reg_bit\(1),
	datad => VCC,
	cin => \pc_counter|auto_generated|counter_comb_bita0~COUT\,
	combout => \pc_counter|auto_generated|counter_comb_bita1~combout\,
	cout => \pc_counter|auto_generated|counter_comb_bita1~COUT\);

-- Location: LCCOMB_X76_Y66_N30
\pc_counter|auto_generated|counter_reg_bit[1]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_reg_bit[1]~4_combout\ = (\mdr_reg|dffs\(1) & ((!\delay|auto_generated|counter_comb_bita1~0_combout\) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(31))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mdr_reg|dffs\(1),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(31),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \pc_counter|auto_generated|counter_reg_bit[1]~4_combout\);

-- Location: LCCOMB_X79_Y66_N18
\x_reg|dffs[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \x_reg|dffs[0]~0_combout\ = !\r1_reg|dffs\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \r1_reg|dffs\(0),
	combout => \x_reg|dffs[0]~0_combout\);

-- Location: LCCOMB_X79_Y66_N20
\ctrlSignals~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~1_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(10) & \delay|auto_generated|counter_comb_bita1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(10),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \ctrlSignals~1_combout\);

-- Location: FF_X79_Y66_N19
\x_reg|dffs[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \x_reg|dffs[0]~0_combout\,
	ena => \ctrlSignals~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \x_reg|dffs\(0));

-- Location: LCCOMB_X77_Y66_N30
\z_mux_out[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \z_mux_out[0]~0_combout\ = \x_reg|dffs\(0) $ (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(11))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \x_reg|dffs\(0),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(11),
	combout => \z_mux_out[0]~0_combout\);

-- Location: LCCOMB_X77_Y66_N0
\ctrlSignals~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(9) & \delay|auto_generated|counter_comb_bita1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(9),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \ctrlSignals~0_combout\);

-- Location: FF_X77_Y66_N31
\z_reg|dffs[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \z_mux_out[0]~0_combout\,
	ena => \ctrlSignals~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \z_reg|dffs\(0));

-- Location: LCCOMB_X77_Y66_N8
\pc_counter|auto_generated|counter_reg_bit[7]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_reg_bit[7]~1_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(12) & (!\z_reg|dffs\(0))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(12) & 
-- ((!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(29))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \z_reg|dffs\(0),
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(29),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(12),
	combout => \pc_counter|auto_generated|counter_reg_bit[7]~1_combout\);

-- Location: LCCOMB_X76_Y66_N28
\pc_counter|auto_generated|counter_reg_bit[7]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_reg_bit[7]~2_combout\ = (\pc_counter|auto_generated|counter_reg_bit[7]~1_combout\ & (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(31) & ((\delay|auto_generated|counter_comb_bita1~0_combout\)))) # 
-- (!\pc_counter|auto_generated|counter_reg_bit[7]~1_combout\ & (((\usequencer|uROM|srom|rom_block|auto_generated|q_a\(12)) # (\delay|auto_generated|counter_comb_bita1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111100001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(31),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(12),
	datac => \pc_counter|auto_generated|counter_reg_bit[7]~1_combout\,
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \pc_counter|auto_generated|counter_reg_bit[7]~2_combout\);

-- Location: LCCOMB_X76_Y66_N4
\ctrlSignals~21\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~21_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(30) & \delay|auto_generated|counter_comb_bita1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(30),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \ctrlSignals~21_combout\);

-- Location: LCCOMB_X76_Y66_N10
\pc_counter|auto_generated|counter_reg_bit[7]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_reg_bit[7]~3_combout\ = ((!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(31) & ((\usequencer|uROM|srom|rom_block|auto_generated|q_a\(12)) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(29))))) # 
-- (!\delay|auto_generated|counter_comb_bita1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(29),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(12),
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(31),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \pc_counter|auto_generated|counter_reg_bit[7]~3_combout\);

-- Location: LCCOMB_X76_Y66_N0
\pc_counter|auto_generated|_~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|_~0_combout\ = (\ctrlSignals~21_combout\) # (((\z_reg|dffs\(0) & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(12))) # (!\pc_counter|auto_generated|counter_reg_bit[7]~3_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \z_reg|dffs\(0),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(12),
	datac => \ctrlSignals~21_combout\,
	datad => \pc_counter|auto_generated|counter_reg_bit[7]~3_combout\,
	combout => \pc_counter|auto_generated|_~0_combout\);

-- Location: FF_X76_Y66_N15
\pc_counter|auto_generated|counter_reg_bit[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \pc_counter|auto_generated|counter_comb_bita1~combout\,
	asdata => \pc_counter|auto_generated|counter_reg_bit[1]~4_combout\,
	sload => \pc_counter|auto_generated|counter_reg_bit[7]~2_combout\,
	ena => \pc_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \pc_counter|auto_generated|counter_reg_bit\(1));

-- Location: LCCOMB_X76_Y66_N16
\pc_counter|auto_generated|counter_comb_bita2\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_comb_bita2~combout\ = (\pc_counter|auto_generated|counter_reg_bit\(2) & (\pc_counter|auto_generated|counter_comb_bita1~COUT\ $ (GND))) # (!\pc_counter|auto_generated|counter_reg_bit\(2) & 
-- (!\pc_counter|auto_generated|counter_comb_bita1~COUT\ & VCC))
-- \pc_counter|auto_generated|counter_comb_bita2~COUT\ = CARRY((\pc_counter|auto_generated|counter_reg_bit\(2) & !\pc_counter|auto_generated|counter_comb_bita1~COUT\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \pc_counter|auto_generated|counter_reg_bit\(2),
	datad => VCC,
	cin => \pc_counter|auto_generated|counter_comb_bita1~COUT\,
	combout => \pc_counter|auto_generated|counter_comb_bita2~combout\,
	cout => \pc_counter|auto_generated|counter_comb_bita2~COUT\);

-- Location: LCCOMB_X76_Y66_N8
\pc_counter|auto_generated|counter_reg_bit[2]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_reg_bit[2]~5_combout\ = (\mdr_reg|dffs\(2) & ((!\delay|auto_generated|counter_comb_bita1~0_combout\) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(31))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \mdr_reg|dffs\(2),
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(31),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \pc_counter|auto_generated|counter_reg_bit[2]~5_combout\);

-- Location: FF_X76_Y66_N17
\pc_counter|auto_generated|counter_reg_bit[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \pc_counter|auto_generated|counter_comb_bita2~combout\,
	asdata => \pc_counter|auto_generated|counter_reg_bit[2]~5_combout\,
	sload => \pc_counter|auto_generated|counter_reg_bit[7]~2_combout\,
	ena => \pc_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \pc_counter|auto_generated|counter_reg_bit\(2));

-- Location: LCCOMB_X76_Y66_N18
\pc_counter|auto_generated|counter_comb_bita3\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_comb_bita3~combout\ = (\pc_counter|auto_generated|counter_reg_bit\(3) & (!\pc_counter|auto_generated|counter_comb_bita2~COUT\)) # (!\pc_counter|auto_generated|counter_reg_bit\(3) & 
-- ((\pc_counter|auto_generated|counter_comb_bita2~COUT\) # (GND)))
-- \pc_counter|auto_generated|counter_comb_bita3~COUT\ = CARRY((!\pc_counter|auto_generated|counter_comb_bita2~COUT\) # (!\pc_counter|auto_generated|counter_reg_bit\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \pc_counter|auto_generated|counter_reg_bit\(3),
	datad => VCC,
	cin => \pc_counter|auto_generated|counter_comb_bita2~COUT\,
	combout => \pc_counter|auto_generated|counter_comb_bita3~combout\,
	cout => \pc_counter|auto_generated|counter_comb_bita3~COUT\);

-- Location: LCCOMB_X76_Y66_N2
\pc_counter|auto_generated|counter_reg_bit[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_reg_bit[3]~6_combout\ = (\mdr_reg|dffs\(3) & ((!\delay|auto_generated|counter_comb_bita1~0_combout\) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(31))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(31),
	datac => \mdr_reg|dffs\(3),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \pc_counter|auto_generated|counter_reg_bit[3]~6_combout\);

-- Location: FF_X76_Y66_N19
\pc_counter|auto_generated|counter_reg_bit[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \pc_counter|auto_generated|counter_comb_bita3~combout\,
	asdata => \pc_counter|auto_generated|counter_reg_bit[3]~6_combout\,
	sload => \pc_counter|auto_generated|counter_reg_bit[7]~2_combout\,
	ena => \pc_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \pc_counter|auto_generated|counter_reg_bit\(3));

-- Location: LCCOMB_X76_Y66_N20
\pc_counter|auto_generated|counter_comb_bita4\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_comb_bita4~combout\ = (\pc_counter|auto_generated|counter_reg_bit\(4) & (\pc_counter|auto_generated|counter_comb_bita3~COUT\ $ (GND))) # (!\pc_counter|auto_generated|counter_reg_bit\(4) & 
-- (!\pc_counter|auto_generated|counter_comb_bita3~COUT\ & VCC))
-- \pc_counter|auto_generated|counter_comb_bita4~COUT\ = CARRY((\pc_counter|auto_generated|counter_reg_bit\(4) & !\pc_counter|auto_generated|counter_comb_bita3~COUT\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \pc_counter|auto_generated|counter_reg_bit\(4),
	datad => VCC,
	cin => \pc_counter|auto_generated|counter_comb_bita3~COUT\,
	combout => \pc_counter|auto_generated|counter_comb_bita4~combout\,
	cout => \pc_counter|auto_generated|counter_comb_bita4~COUT\);

-- Location: LCCOMB_X75_Y67_N12
\mdr_reg|dffs[4]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \mdr_reg|dffs[4]~4_combout\ = (\ir_reg|dffs\(0) & (\r1_reg|dffs\(4))) # (!\ir_reg|dffs\(0) & ((\r0_reg|dffs\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(4),
	datab => \r0_reg|dffs\(4),
	datad => \ir_reg|dffs\(0),
	combout => \mdr_reg|dffs[4]~4_combout\);

-- Location: LCCOMB_X77_Y66_N18
\sp_counter|auto_generated|counter_comb_bita4\ : cycloneive_lcell_comb
-- Equation(s):
-- \sp_counter|auto_generated|counter_comb_bita4~combout\ = (\sp_counter|auto_generated|counter_comb_bita3~COUT\ & (\sp_counter|auto_generated|counter_reg_bit\(4) & ((VCC)))) # (!\sp_counter|auto_generated|counter_comb_bita3~COUT\ & 
-- (\sp_counter|auto_generated|counter_reg_bit\(4) $ (((VCC) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20))))))
-- \sp_counter|auto_generated|counter_comb_bita4~COUT\ = CARRY((!\sp_counter|auto_generated|counter_comb_bita3~COUT\ & (\sp_counter|auto_generated|counter_reg_bit\(4) $ (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \sp_counter|auto_generated|counter_reg_bit\(4),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(20),
	datad => VCC,
	cin => \sp_counter|auto_generated|counter_comb_bita3~COUT\,
	combout => \sp_counter|auto_generated|counter_comb_bita4~combout\,
	cout => \sp_counter|auto_generated|counter_comb_bita4~COUT\);

-- Location: FF_X77_Y66_N19
\sp_counter|auto_generated|counter_reg_bit[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \sp_counter|auto_generated|counter_comb_bita4~combout\,
	asdata => \mdr_reg|dffs\(4),
	sload => \ctrlSignals~12_combout\,
	ena => \sp_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \sp_counter|auto_generated|counter_reg_bit\(4));

-- Location: LCCOMB_X77_Y66_N20
\sp_counter|auto_generated|counter_comb_bita5\ : cycloneive_lcell_comb
-- Equation(s):
-- \sp_counter|auto_generated|counter_comb_bita5~combout\ = (\sp_counter|auto_generated|counter_comb_bita4~COUT\ & (\sp_counter|auto_generated|counter_reg_bit\(5) $ (((\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20)) # (VCC))))) # 
-- (!\sp_counter|auto_generated|counter_comb_bita4~COUT\ & (((\sp_counter|auto_generated|counter_reg_bit\(5)) # (GND))))
-- \sp_counter|auto_generated|counter_comb_bita5~COUT\ = CARRY((\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20) $ (\sp_counter|auto_generated|counter_reg_bit\(5))) # (!\sp_counter|auto_generated|counter_comb_bita4~COUT\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110001101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(20),
	datab => \sp_counter|auto_generated|counter_reg_bit\(5),
	datad => VCC,
	cin => \sp_counter|auto_generated|counter_comb_bita4~COUT\,
	combout => \sp_counter|auto_generated|counter_comb_bita5~combout\,
	cout => \sp_counter|auto_generated|counter_comb_bita5~COUT\);

-- Location: LCCOMB_X75_Y67_N26
\mdr_reg|dffs[5]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \mdr_reg|dffs[5]~5_combout\ = (\ir_reg|dffs\(0) & (\r1_reg|dffs\(5))) # (!\ir_reg|dffs\(0) & ((\r0_reg|dffs\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(5),
	datab => \r0_reg|dffs\(5),
	datad => \ir_reg|dffs\(0),
	combout => \mdr_reg|dffs[5]~5_combout\);

-- Location: LCCOMB_X76_Y66_N22
\pc_counter|auto_generated|counter_comb_bita5\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_comb_bita5~combout\ = (\pc_counter|auto_generated|counter_reg_bit\(5) & (!\pc_counter|auto_generated|counter_comb_bita4~COUT\)) # (!\pc_counter|auto_generated|counter_reg_bit\(5) & 
-- ((\pc_counter|auto_generated|counter_comb_bita4~COUT\) # (GND)))
-- \pc_counter|auto_generated|counter_comb_bita5~COUT\ = CARRY((!\pc_counter|auto_generated|counter_comb_bita4~COUT\) # (!\pc_counter|auto_generated|counter_reg_bit\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(5),
	datad => VCC,
	cin => \pc_counter|auto_generated|counter_comb_bita4~COUT\,
	combout => \pc_counter|auto_generated|counter_comb_bita5~combout\,
	cout => \pc_counter|auto_generated|counter_comb_bita5~COUT\);

-- Location: LCCOMB_X75_Y66_N14
\pc_counter|auto_generated|counter_reg_bit[5]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_reg_bit[5]~8_combout\ = (\mdr_reg|dffs\(5) & ((!\delay|auto_generated|counter_comb_bita1~0_combout\) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(31))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(31),
	datac => \mdr_reg|dffs\(5),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \pc_counter|auto_generated|counter_reg_bit[5]~8_combout\);

-- Location: FF_X76_Y66_N23
\pc_counter|auto_generated|counter_reg_bit[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \pc_counter|auto_generated|counter_comb_bita5~combout\,
	asdata => \pc_counter|auto_generated|counter_reg_bit[5]~8_combout\,
	sload => \pc_counter|auto_generated|counter_reg_bit[7]~2_combout\,
	ena => \pc_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \pc_counter|auto_generated|counter_reg_bit\(5));

-- Location: LCCOMB_X76_Y66_N24
\pc_counter|auto_generated|counter_comb_bita6\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_comb_bita6~combout\ = (\pc_counter|auto_generated|counter_reg_bit\(6) & (\pc_counter|auto_generated|counter_comb_bita5~COUT\ $ (GND))) # (!\pc_counter|auto_generated|counter_reg_bit\(6) & 
-- (!\pc_counter|auto_generated|counter_comb_bita5~COUT\ & VCC))
-- \pc_counter|auto_generated|counter_comb_bita6~COUT\ = CARRY((\pc_counter|auto_generated|counter_reg_bit\(6) & !\pc_counter|auto_generated|counter_comb_bita5~COUT\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \pc_counter|auto_generated|counter_reg_bit\(6),
	datad => VCC,
	cin => \pc_counter|auto_generated|counter_comb_bita5~COUT\,
	combout => \pc_counter|auto_generated|counter_comb_bita6~combout\,
	cout => \pc_counter|auto_generated|counter_comb_bita6~COUT\);

-- Location: LCCOMB_X75_Y66_N4
\pc_counter|auto_generated|counter_reg_bit[6]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_reg_bit[6]~9_combout\ = (\mdr_reg|dffs\(6) & ((!\delay|auto_generated|counter_comb_bita1~0_combout\) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(31))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(31),
	datac => \mdr_reg|dffs\(6),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \pc_counter|auto_generated|counter_reg_bit[6]~9_combout\);

-- Location: FF_X76_Y66_N25
\pc_counter|auto_generated|counter_reg_bit[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \pc_counter|auto_generated|counter_comb_bita6~combout\,
	asdata => \pc_counter|auto_generated|counter_reg_bit[6]~9_combout\,
	sload => \pc_counter|auto_generated|counter_reg_bit[7]~2_combout\,
	ena => \pc_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \pc_counter|auto_generated|counter_reg_bit\(6));

-- Location: LCCOMB_X77_Y66_N22
\sp_counter|auto_generated|counter_comb_bita6\ : cycloneive_lcell_comb
-- Equation(s):
-- \sp_counter|auto_generated|counter_comb_bita6~combout\ = (\sp_counter|auto_generated|counter_comb_bita5~COUT\ & (\sp_counter|auto_generated|counter_reg_bit\(6) & ((VCC)))) # (!\sp_counter|auto_generated|counter_comb_bita5~COUT\ & 
-- (\sp_counter|auto_generated|counter_reg_bit\(6) $ (((VCC) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20))))))
-- \sp_counter|auto_generated|counter_comb_bita6~COUT\ = CARRY((!\sp_counter|auto_generated|counter_comb_bita5~COUT\ & (\sp_counter|auto_generated|counter_reg_bit\(6) $ (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \sp_counter|auto_generated|counter_reg_bit\(6),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(20),
	datad => VCC,
	cin => \sp_counter|auto_generated|counter_comb_bita5~COUT\,
	combout => \sp_counter|auto_generated|counter_comb_bita6~combout\,
	cout => \sp_counter|auto_generated|counter_comb_bita6~COUT\);

-- Location: FF_X77_Y66_N23
\sp_counter|auto_generated|counter_reg_bit[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \sp_counter|auto_generated|counter_comb_bita6~combout\,
	asdata => \mdr_reg|dffs\(6),
	sload => \ctrlSignals~12_combout\,
	ena => \sp_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \sp_counter|auto_generated|counter_reg_bit\(6));

-- Location: LCCOMB_X76_Y67_N16
\mar_reg|dffs[6]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \mar_reg|dffs[6]~6_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & (\pc_counter|auto_generated|counter_reg_bit\(6))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & ((\sp_counter|auto_generated|counter_reg_bit\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(6),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(24),
	datad => \sp_counter|auto_generated|counter_reg_bit\(6),
	combout => \mar_reg|dffs[6]~6_combout\);

-- Location: FF_X76_Y67_N17
\mar_reg|dffs[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mar_reg|dffs[6]~6_combout\,
	asdata => \mdr_reg|dffs\(6),
	sclr => \mar_reg|dffs[7]~8_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(25),
	ena => \ctrlSignals~17_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mar_reg|dffs\(6));

-- Location: LCCOMB_X77_Y66_N24
\sp_counter|auto_generated|counter_comb_bita7\ : cycloneive_lcell_comb
-- Equation(s):
-- \sp_counter|auto_generated|counter_comb_bita7~combout\ = \sp_counter|auto_generated|counter_comb_bita6~COUT\ $ (\sp_counter|auto_generated|counter_reg_bit\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \sp_counter|auto_generated|counter_reg_bit\(7),
	cin => \sp_counter|auto_generated|counter_comb_bita6~COUT\,
	combout => \sp_counter|auto_generated|counter_comb_bita7~combout\);

-- Location: FF_X77_Y66_N25
\sp_counter|auto_generated|counter_reg_bit[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \sp_counter|auto_generated|counter_comb_bita7~combout\,
	asdata => \mdr_reg|dffs\(7),
	sload => \ctrlSignals~12_combout\,
	ena => \sp_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \sp_counter|auto_generated|counter_reg_bit\(7));

-- Location: LCCOMB_X76_Y66_N26
\pc_counter|auto_generated|counter_comb_bita7\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_comb_bita7~combout\ = \pc_counter|auto_generated|counter_comb_bita6~COUT\ $ (\pc_counter|auto_generated|counter_reg_bit\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \pc_counter|auto_generated|counter_reg_bit\(7),
	cin => \pc_counter|auto_generated|counter_comb_bita6~COUT\,
	combout => \pc_counter|auto_generated|counter_comb_bita7~combout\);

-- Location: LCCOMB_X75_Y66_N26
\pc_counter|auto_generated|counter_reg_bit[7]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_reg_bit[7]~10_combout\ = (\mdr_reg|dffs\(7) & ((!\delay|auto_generated|counter_comb_bita1~0_combout\) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(31))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mdr_reg|dffs\(7),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(31),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \pc_counter|auto_generated|counter_reg_bit[7]~10_combout\);

-- Location: FF_X76_Y66_N27
\pc_counter|auto_generated|counter_reg_bit[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \pc_counter|auto_generated|counter_comb_bita7~combout\,
	asdata => \pc_counter|auto_generated|counter_reg_bit[7]~10_combout\,
	sload => \pc_counter|auto_generated|counter_reg_bit[7]~2_combout\,
	ena => \pc_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \pc_counter|auto_generated|counter_reg_bit\(7));

-- Location: LCCOMB_X76_Y67_N2
\mar_reg|dffs[7]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \mar_reg|dffs[7]~7_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & ((\pc_counter|auto_generated|counter_reg_bit\(7)))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & (\sp_counter|auto_generated|counter_reg_bit\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sp_counter|auto_generated|counter_reg_bit\(7),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(24),
	datad => \pc_counter|auto_generated|counter_reg_bit\(7),
	combout => \mar_reg|dffs[7]~7_combout\);

-- Location: FF_X76_Y67_N3
\mar_reg|dffs[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mar_reg|dffs[7]~7_combout\,
	asdata => \mdr_reg|dffs\(7),
	sclr => \mar_reg|dffs[7]~8_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(25),
	ena => \ctrlSignals~17_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mar_reg|dffs\(7));

-- Location: M9K_X78_Y67_N0
\Ram|sram|ram_block|auto_generated|ram_block1a0\ : cycloneive_ram_block
-- pragma translate_off
GENERIC MAP (
	mem_init2 => X"000000000000000000000000000000000000000000000000000000000D0001200000000000000000000000000000000000000000000000000000000000000000",
	mem_init1 => X"00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
	mem_init0 => X"000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000F00000000000008800A0002000000001C0001D0024000E10038000C00034400D00030C00B0001040040003CC0021003C80020003C40031003C000300020000700018000500000C0011000140010",
	data_interleave_offset_in_bits => 1,
	data_interleave_width_in_bits => 1,
	init_file => "lab7_ram01.mif",
	init_file_layout => "port_a",
	logical_ram_name => "lpm_ram_dq:Ram|altram:sram|altsyncram:ram_block|altsyncram_nu91:auto_generated|ALTSYNCRAM",
	operation_mode => "single_port",
	port_a_address_clear => "none",
	port_a_address_width => 8,
	port_a_byte_enable_clock => "none",
	port_a_data_out_clear => "none",
	port_a_data_out_clock => "clock0",
	port_a_data_width => 18,
	port_a_first_address => 0,
	port_a_first_bit_number => 0,
	port_a_last_address => 255,
	port_a_logical_ram_depth => 256,
	port_a_logical_ram_width => 8,
	port_a_read_during_write_mode => "new_data_with_nbe_read",
	port_b_address_width => 8,
	port_b_data_width => 18,
	ram_block_type => "M9K")
-- pragma translate_on
PORT MAP (
	portawe => \ctrlSignals~14_combout\,
	portare => VCC,
	clk0 => \clk~inputclkctrl_outclk\,
	clk1 => GND,
	portadatain => \Ram|sram|ram_block|auto_generated|ram_block1a0_PORTADATAIN_bus\,
	portaaddr => \Ram|sram|ram_block|auto_generated|ram_block1a0_PORTAADDR_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	portadataout => \Ram|sram|ram_block|auto_generated|ram_block1a0_PORTADATAOUT_bus\);

-- Location: LCCOMB_X75_Y67_N28
\ctrlSignals~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~19_combout\ = (\delay|auto_generated|counter_comb_bita1~0_combout\ & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(28))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \delay|auto_generated|counter_comb_bita1~0_combout\,
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(28),
	combout => \ctrlSignals~19_combout\);

-- Location: FF_X75_Y67_N27
\mdr_reg|dffs[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mdr_reg|dffs[5]~5_combout\,
	asdata => \Ram|sram|ram_block|auto_generated|q_a\(5),
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(27),
	ena => \ctrlSignals~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mdr_reg|dffs\(5));

-- Location: FF_X77_Y66_N21
\sp_counter|auto_generated|counter_reg_bit[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \sp_counter|auto_generated|counter_comb_bita5~combout\,
	asdata => \mdr_reg|dffs\(5),
	sload => \ctrlSignals~12_combout\,
	ena => \sp_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \sp_counter|auto_generated|counter_reg_bit\(5));

-- Location: LCCOMB_X76_Y67_N26
\mar_reg|dffs[5]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \mar_reg|dffs[5]~5_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & ((\pc_counter|auto_generated|counter_reg_bit\(5)))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & (\sp_counter|auto_generated|counter_reg_bit\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sp_counter|auto_generated|counter_reg_bit\(5),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(24),
	datad => \pc_counter|auto_generated|counter_reg_bit\(5),
	combout => \mar_reg|dffs[5]~5_combout\);

-- Location: FF_X76_Y67_N27
\mar_reg|dffs[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mar_reg|dffs[5]~5_combout\,
	asdata => \mdr_reg|dffs\(5),
	sclr => \mar_reg|dffs[7]~8_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(25),
	ena => \ctrlSignals~17_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mar_reg|dffs\(5));

-- Location: FF_X75_Y67_N13
\mdr_reg|dffs[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mdr_reg|dffs[4]~4_combout\,
	asdata => \Ram|sram|ram_block|auto_generated|q_a\(4),
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(27),
	ena => \ctrlSignals~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mdr_reg|dffs\(4));

-- Location: LCCOMB_X75_Y66_N16
\pc_counter|auto_generated|counter_reg_bit[4]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_reg_bit[4]~7_combout\ = (\mdr_reg|dffs\(4) & ((!\delay|auto_generated|counter_comb_bita1~0_combout\) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(31))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mdr_reg|dffs\(4),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(31),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \pc_counter|auto_generated|counter_reg_bit[4]~7_combout\);

-- Location: FF_X76_Y66_N21
\pc_counter|auto_generated|counter_reg_bit[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \pc_counter|auto_generated|counter_comb_bita4~combout\,
	asdata => \pc_counter|auto_generated|counter_reg_bit[4]~7_combout\,
	sload => \pc_counter|auto_generated|counter_reg_bit[7]~2_combout\,
	ena => \pc_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \pc_counter|auto_generated|counter_reg_bit\(4));

-- Location: LCCOMB_X76_Y67_N20
\mar_reg|dffs[4]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \mar_reg|dffs[4]~4_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & (\pc_counter|auto_generated|counter_reg_bit\(4))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & ((\sp_counter|auto_generated|counter_reg_bit\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(4),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(24),
	datad => \sp_counter|auto_generated|counter_reg_bit\(4),
	combout => \mar_reg|dffs[4]~4_combout\);

-- Location: FF_X76_Y67_N21
\mar_reg|dffs[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mar_reg|dffs[4]~4_combout\,
	asdata => \mdr_reg|dffs\(4),
	sclr => \mar_reg|dffs[7]~8_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(25),
	ena => \ctrlSignals~17_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mar_reg|dffs\(4));

-- Location: FF_X75_Y67_N19
\mdr_reg|dffs[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mdr_reg|dffs[3]~3_combout\,
	asdata => \Ram|sram|ram_block|auto_generated|q_a\(3),
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(27),
	ena => \ctrlSignals~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mdr_reg|dffs\(3));

-- Location: FF_X77_Y66_N17
\sp_counter|auto_generated|counter_reg_bit[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \sp_counter|auto_generated|counter_comb_bita3~combout\,
	asdata => \mdr_reg|dffs\(3),
	sload => \ctrlSignals~12_combout\,
	ena => \sp_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \sp_counter|auto_generated|counter_reg_bit\(3));

-- Location: LCCOMB_X76_Y67_N14
\mar_reg|dffs[3]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \mar_reg|dffs[3]~3_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & ((\pc_counter|auto_generated|counter_reg_bit\(3)))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & (\sp_counter|auto_generated|counter_reg_bit\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sp_counter|auto_generated|counter_reg_bit\(3),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(24),
	datad => \pc_counter|auto_generated|counter_reg_bit\(3),
	combout => \mar_reg|dffs[3]~3_combout\);

-- Location: FF_X76_Y67_N15
\mar_reg|dffs[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mar_reg|dffs[3]~3_combout\,
	asdata => \mdr_reg|dffs\(3),
	sclr => \mar_reg|dffs[7]~8_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(25),
	ena => \ctrlSignals~17_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mar_reg|dffs\(3));

-- Location: FF_X75_Y67_N1
\mdr_reg|dffs[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mdr_reg|dffs[2]~2_combout\,
	asdata => \Ram|sram|ram_block|auto_generated|q_a\(2),
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(27),
	ena => \ctrlSignals~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mdr_reg|dffs\(2));

-- Location: FF_X77_Y66_N15
\sp_counter|auto_generated|counter_reg_bit[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \sp_counter|auto_generated|counter_comb_bita2~combout\,
	asdata => \mdr_reg|dffs\(2),
	sload => \ctrlSignals~12_combout\,
	ena => \sp_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \sp_counter|auto_generated|counter_reg_bit\(2));

-- Location: LCCOMB_X76_Y67_N12
\mar_reg|dffs[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \mar_reg|dffs[2]~2_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & ((\pc_counter|auto_generated|counter_reg_bit\(2)))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & (\sp_counter|auto_generated|counter_reg_bit\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sp_counter|auto_generated|counter_reg_bit\(2),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(24),
	datad => \pc_counter|auto_generated|counter_reg_bit\(2),
	combout => \mar_reg|dffs[2]~2_combout\);

-- Location: FF_X76_Y67_N13
\mar_reg|dffs[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mar_reg|dffs[2]~2_combout\,
	asdata => \mdr_reg|dffs\(2),
	sclr => \mar_reg|dffs[7]~8_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(25),
	ena => \ctrlSignals~17_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mar_reg|dffs\(2));

-- Location: FF_X75_Y67_N7
\mdr_reg|dffs[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mdr_reg|dffs[1]~1_combout\,
	asdata => \Ram|sram|ram_block|auto_generated|q_a\(1),
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(27),
	ena => \ctrlSignals~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mdr_reg|dffs\(1));

-- Location: FF_X77_Y66_N13
\sp_counter|auto_generated|counter_reg_bit[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \sp_counter|auto_generated|counter_comb_bita1~combout\,
	asdata => \mdr_reg|dffs\(1),
	sload => \ctrlSignals~12_combout\,
	ena => \sp_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \sp_counter|auto_generated|counter_reg_bit\(1));

-- Location: LCCOMB_X76_Y67_N6
\mar_reg|dffs[1]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \mar_reg|dffs[1]~1_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & ((\pc_counter|auto_generated|counter_reg_bit\(1)))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & (\sp_counter|auto_generated|counter_reg_bit\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sp_counter|auto_generated|counter_reg_bit\(1),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(24),
	datad => \pc_counter|auto_generated|counter_reg_bit\(1),
	combout => \mar_reg|dffs[1]~1_combout\);

-- Location: FF_X76_Y67_N7
\mar_reg|dffs[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mar_reg|dffs[1]~1_combout\,
	asdata => \mdr_reg|dffs\(1),
	sclr => \mar_reg|dffs[7]~8_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(25),
	ena => \ctrlSignals~17_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mar_reg|dffs\(1));

-- Location: FF_X75_Y67_N17
\mdr_reg|dffs[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mdr_reg|dffs[0]~0_combout\,
	asdata => \Ram|sram|ram_block|auto_generated|q_a\(0),
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(27),
	ena => \ctrlSignals~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mdr_reg|dffs\(0));

-- Location: LCCOMB_X74_Y66_N0
\Mux15~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux15~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & (\r1_reg|dffs\(0))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & ((\mdr_reg|dffs\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(0),
	datab => \mdr_reg|dffs\(0),
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(16),
	combout => \Mux15~0_combout\);

-- Location: LCCOMB_X75_Y67_N22
\r0_reg|dffs[7]~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0_reg|dffs[7]~20_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(17) & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(16))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(17),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(16),
	combout => \r0_reg|dffs[7]~20_combout\);

-- Location: LCCOMB_X74_Y67_N4
r0_enable : cycloneive_lcell_comb
-- Equation(s):
-- \r0_enable~combout\ = (!\ir_reg|dffs\(0) & (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(13) & \delay|auto_generated|counter_comb_bita1~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \ir_reg|dffs\(0),
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(13),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \r0_enable~combout\);

-- Location: FF_X74_Y67_N9
\r0_reg|dffs[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r0_reg|dffs[0]~10_combout\,
	asdata => \Mux15~0_combout\,
	sclr => \r0_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(17),
	ena => \r0_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r0_reg|dffs\(0));

-- Location: LCCOMB_X73_Y66_N2
\r1add|auto_generated|_~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1add|auto_generated|_~4_combout\ = \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18) $ (\r0_reg|dffs\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	datad => \r0_reg|dffs\(0),
	combout => \r1add|auto_generated|_~4_combout\);

-- Location: LCCOMB_X73_Y66_N6
\r1_reg|dffs[0]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1_reg|dffs[0]~9_cout\ = CARRY(!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(18))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	datad => VCC,
	cout => \r1_reg|dffs[0]~9_cout\);

-- Location: LCCOMB_X73_Y66_N8
\r1_reg|dffs[0]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1_reg|dffs[0]~10_combout\ = (\r1_reg|dffs\(0) & ((\r1add|auto_generated|_~4_combout\ & (!\r1_reg|dffs[0]~9_cout\)) # (!\r1add|auto_generated|_~4_combout\ & (\r1_reg|dffs[0]~9_cout\ & VCC)))) # (!\r1_reg|dffs\(0) & ((\r1add|auto_generated|_~4_combout\ & 
-- ((\r1_reg|dffs[0]~9_cout\) # (GND))) # (!\r1add|auto_generated|_~4_combout\ & (!\r1_reg|dffs[0]~9_cout\))))
-- \r1_reg|dffs[0]~11\ = CARRY((\r1_reg|dffs\(0) & (\r1add|auto_generated|_~4_combout\ & !\r1_reg|dffs[0]~9_cout\)) # (!\r1_reg|dffs\(0) & ((\r1add|auto_generated|_~4_combout\) # (!\r1_reg|dffs[0]~9_cout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100101001101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(0),
	datab => \r1add|auto_generated|_~4_combout\,
	datad => VCC,
	cin => \r1_reg|dffs[0]~9_cout\,
	combout => \r1_reg|dffs[0]~10_combout\,
	cout => \r1_reg|dffs[0]~11\);

-- Location: LCCOMB_X74_Y66_N10
\Mux23~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux23~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & (\r0_reg|dffs\(0))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & ((\mdr_reg|dffs\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(0),
	datac => \mdr_reg|dffs\(0),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(14),
	combout => \Mux23~0_combout\);

-- Location: LCCOMB_X74_Y66_N26
\r1_reg|dffs[7]~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1_reg|dffs[7]~20_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(15) & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(14))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(15),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(14),
	combout => \r1_reg|dffs[7]~20_combout\);

-- Location: LCCOMB_X73_Y66_N4
r1_enable : cycloneive_lcell_comb
-- Equation(s):
-- \r1_enable~combout\ = (\ir_reg|dffs\(0) & (\delay|auto_generated|counter_comb_bita1~0_combout\ & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \ir_reg|dffs\(0),
	datac => \delay|auto_generated|counter_comb_bita1~0_combout\,
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(13),
	combout => \r1_enable~combout\);

-- Location: FF_X73_Y66_N9
\r1_reg|dffs[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r1_reg|dffs[0]~10_combout\,
	asdata => \Mux23~0_combout\,
	sclr => \r1_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(15),
	ena => \r1_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r1_reg|dffs\(0));

-- Location: LCCOMB_X73_Y66_N10
\r1_reg|dffs[1]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1_reg|dffs[1]~12_combout\ = ((\r1_reg|dffs\(1) $ (\r1add|auto_generated|_~3_combout\ $ (\r1_reg|dffs[0]~11\)))) # (GND)
-- \r1_reg|dffs[1]~13\ = CARRY((\r1_reg|dffs\(1) & ((!\r1_reg|dffs[0]~11\) # (!\r1add|auto_generated|_~3_combout\))) # (!\r1_reg|dffs\(1) & (!\r1add|auto_generated|_~3_combout\ & !\r1_reg|dffs[0]~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000101011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(1),
	datab => \r1add|auto_generated|_~3_combout\,
	datad => VCC,
	cin => \r1_reg|dffs[0]~11\,
	combout => \r1_reg|dffs[1]~12_combout\,
	cout => \r1_reg|dffs[1]~13\);

-- Location: LCCOMB_X74_Y66_N16
\Mux22~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux22~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & ((\r0_reg|dffs\(1)))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & (\mdr_reg|dffs\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(14),
	datab => \mdr_reg|dffs\(1),
	datad => \r0_reg|dffs\(1),
	combout => \Mux22~0_combout\);

-- Location: FF_X73_Y66_N11
\r1_reg|dffs[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r1_reg|dffs[1]~12_combout\,
	asdata => \Mux22~0_combout\,
	sclr => \r1_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(15),
	ena => \r1_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r1_reg|dffs\(1));

-- Location: LCCOMB_X74_Y67_N24
\r0add|auto_generated|_~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0add|auto_generated|_~3_combout\ = \r1_reg|dffs\(1) $ (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(18))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(1),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	combout => \r0add|auto_generated|_~3_combout\);

-- Location: LCCOMB_X74_Y67_N10
\r0_reg|dffs[1]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0_reg|dffs[1]~12_combout\ = ((\r0_reg|dffs\(1) $ (\r0add|auto_generated|_~3_combout\ $ (\r0_reg|dffs[0]~11\)))) # (GND)
-- \r0_reg|dffs[1]~13\ = CARRY((\r0_reg|dffs\(1) & ((!\r0_reg|dffs[0]~11\) # (!\r0add|auto_generated|_~3_combout\))) # (!\r0_reg|dffs\(1) & (!\r0add|auto_generated|_~3_combout\ & !\r0_reg|dffs[0]~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000101011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(1),
	datab => \r0add|auto_generated|_~3_combout\,
	datad => VCC,
	cin => \r0_reg|dffs[0]~11\,
	combout => \r0_reg|dffs[1]~12_combout\,
	cout => \r0_reg|dffs[1]~13\);

-- Location: LCCOMB_X75_Y67_N8
\Mux14~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux14~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & ((\r1_reg|dffs\(1)))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & (\mdr_reg|dffs\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mdr_reg|dffs\(1),
	datac => \r1_reg|dffs\(1),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(16),
	combout => \Mux14~0_combout\);

-- Location: FF_X74_Y67_N11
\r0_reg|dffs[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r0_reg|dffs[1]~12_combout\,
	asdata => \Mux14~0_combout\,
	sclr => \r0_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(17),
	ena => \r0_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r0_reg|dffs\(1));

-- Location: LCCOMB_X74_Y67_N12
\r0_reg|dffs[2]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0_reg|dffs[2]~14_combout\ = (\r0_reg|dffs\(2) & ((\r0add|auto_generated|_~2_combout\ & (!\r0_reg|dffs[1]~13\)) # (!\r0add|auto_generated|_~2_combout\ & (\r0_reg|dffs[1]~13\ & VCC)))) # (!\r0_reg|dffs\(2) & ((\r0add|auto_generated|_~2_combout\ & 
-- ((\r0_reg|dffs[1]~13\) # (GND))) # (!\r0add|auto_generated|_~2_combout\ & (!\r0_reg|dffs[1]~13\))))
-- \r0_reg|dffs[2]~15\ = CARRY((\r0_reg|dffs\(2) & (\r0add|auto_generated|_~2_combout\ & !\r0_reg|dffs[1]~13\)) # (!\r0_reg|dffs\(2) & ((\r0add|auto_generated|_~2_combout\) # (!\r0_reg|dffs[1]~13\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100101001101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(2),
	datab => \r0add|auto_generated|_~2_combout\,
	datad => VCC,
	cin => \r0_reg|dffs[1]~13\,
	combout => \r0_reg|dffs[2]~14_combout\,
	cout => \r0_reg|dffs[2]~15\);

-- Location: LCCOMB_X75_Y67_N14
\Mux13~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux13~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & (\r1_reg|dffs\(2))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & ((\mdr_reg|dffs\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \r1_reg|dffs\(2),
	datac => \mdr_reg|dffs\(2),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(16),
	combout => \Mux13~0_combout\);

-- Location: FF_X74_Y67_N13
\r0_reg|dffs[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r0_reg|dffs[2]~14_combout\,
	asdata => \Mux13~0_combout\,
	sclr => \r0_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(17),
	ena => \r0_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r0_reg|dffs\(2));

-- Location: LCCOMB_X73_Y66_N28
\r1add|auto_generated|_~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1add|auto_generated|_~2_combout\ = \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18) $ (\r0_reg|dffs\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	datad => \r0_reg|dffs\(2),
	combout => \r1add|auto_generated|_~2_combout\);

-- Location: LCCOMB_X73_Y66_N12
\r1_reg|dffs[2]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1_reg|dffs[2]~14_combout\ = (\r1_reg|dffs\(2) & ((\r1add|auto_generated|_~2_combout\ & (!\r1_reg|dffs[1]~13\)) # (!\r1add|auto_generated|_~2_combout\ & (\r1_reg|dffs[1]~13\ & VCC)))) # (!\r1_reg|dffs\(2) & ((\r1add|auto_generated|_~2_combout\ & 
-- ((\r1_reg|dffs[1]~13\) # (GND))) # (!\r1add|auto_generated|_~2_combout\ & (!\r1_reg|dffs[1]~13\))))
-- \r1_reg|dffs[2]~15\ = CARRY((\r1_reg|dffs\(2) & (\r1add|auto_generated|_~2_combout\ & !\r1_reg|dffs[1]~13\)) # (!\r1_reg|dffs\(2) & ((\r1add|auto_generated|_~2_combout\) # (!\r1_reg|dffs[1]~13\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100101001101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(2),
	datab => \r1add|auto_generated|_~2_combout\,
	datad => VCC,
	cin => \r1_reg|dffs[1]~13\,
	combout => \r1_reg|dffs[2]~14_combout\,
	cout => \r1_reg|dffs[2]~15\);

-- Location: LCCOMB_X74_Y66_N14
\Mux21~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux21~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & (\r0_reg|dffs\(2))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & ((\mdr_reg|dffs\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(2),
	datac => \mdr_reg|dffs\(2),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(14),
	combout => \Mux21~0_combout\);

-- Location: FF_X73_Y66_N13
\r1_reg|dffs[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r1_reg|dffs[2]~14_combout\,
	asdata => \Mux21~0_combout\,
	sclr => \r1_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(15),
	ena => \r1_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r1_reg|dffs\(2));

-- Location: LCCOMB_X73_Y66_N14
\r1_reg|dffs[3]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1_reg|dffs[3]~16_combout\ = ((\r1add|auto_generated|_~1_combout\ $ (\r1_reg|dffs\(3) $ (\r1_reg|dffs[2]~15\)))) # (GND)
-- \r1_reg|dffs[3]~17\ = CARRY((\r1add|auto_generated|_~1_combout\ & (\r1_reg|dffs\(3) & !\r1_reg|dffs[2]~15\)) # (!\r1add|auto_generated|_~1_combout\ & ((\r1_reg|dffs\(3)) # (!\r1_reg|dffs[2]~15\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011001001101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \r1add|auto_generated|_~1_combout\,
	datab => \r1_reg|dffs\(3),
	datad => VCC,
	cin => \r1_reg|dffs[2]~15\,
	combout => \r1_reg|dffs[3]~16_combout\,
	cout => \r1_reg|dffs[3]~17\);

-- Location: LCCOMB_X74_Y66_N20
\Mux20~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux20~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & (\r0_reg|dffs\(3))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & ((\mdr_reg|dffs\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(3),
	datab => \mdr_reg|dffs\(3),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(14),
	combout => \Mux20~0_combout\);

-- Location: FF_X73_Y66_N15
\r1_reg|dffs[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r1_reg|dffs[3]~16_combout\,
	asdata => \Mux20~0_combout\,
	sclr => \r1_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(15),
	ena => \r1_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r1_reg|dffs\(3));

-- Location: LCCOMB_X74_Y67_N26
\r0add|auto_generated|_~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0add|auto_generated|_~1_combout\ = \r1_reg|dffs\(3) $ (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(18))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(3),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	combout => \r0add|auto_generated|_~1_combout\);

-- Location: LCCOMB_X74_Y67_N14
\r0_reg|dffs[3]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0_reg|dffs[3]~16_combout\ = ((\r0add|auto_generated|_~1_combout\ $ (\r0_reg|dffs\(3) $ (\r0_reg|dffs[2]~15\)))) # (GND)
-- \r0_reg|dffs[3]~17\ = CARRY((\r0add|auto_generated|_~1_combout\ & (\r0_reg|dffs\(3) & !\r0_reg|dffs[2]~15\)) # (!\r0add|auto_generated|_~1_combout\ & ((\r0_reg|dffs\(3)) # (!\r0_reg|dffs[2]~15\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011001001101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \r0add|auto_generated|_~1_combout\,
	datab => \r0_reg|dffs\(3),
	datad => VCC,
	cin => \r0_reg|dffs[2]~15\,
	combout => \r0_reg|dffs[3]~16_combout\,
	cout => \r0_reg|dffs[3]~17\);

-- Location: LCCOMB_X74_Y66_N30
\Mux12~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux12~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & (\r1_reg|dffs\(3))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & ((\mdr_reg|dffs\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(3),
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(16),
	datad => \mdr_reg|dffs\(3),
	combout => \Mux12~0_combout\);

-- Location: FF_X74_Y67_N15
\r0_reg|dffs[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r0_reg|dffs[3]~16_combout\,
	asdata => \Mux12~0_combout\,
	sclr => \r0_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(17),
	ena => \r0_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r0_reg|dffs\(3));

-- Location: LCCOMB_X73_Y66_N26
\r1add|auto_generated|_~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1add|auto_generated|_~1_combout\ = \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18) $ (\r0_reg|dffs\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	datad => \r0_reg|dffs\(3),
	combout => \r1add|auto_generated|_~1_combout\);

-- Location: LCCOMB_X73_Y66_N16
\r1_reg|dffs[4]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1_reg|dffs[4]~18_combout\ = (\r1_reg|dffs\(4) & ((\r1add|auto_generated|_~0_combout\ & (!\r1_reg|dffs[3]~17\)) # (!\r1add|auto_generated|_~0_combout\ & (\r1_reg|dffs[3]~17\ & VCC)))) # (!\r1_reg|dffs\(4) & ((\r1add|auto_generated|_~0_combout\ & 
-- ((\r1_reg|dffs[3]~17\) # (GND))) # (!\r1add|auto_generated|_~0_combout\ & (!\r1_reg|dffs[3]~17\))))
-- \r1_reg|dffs[4]~19\ = CARRY((\r1_reg|dffs\(4) & (\r1add|auto_generated|_~0_combout\ & !\r1_reg|dffs[3]~17\)) # (!\r1_reg|dffs\(4) & ((\r1add|auto_generated|_~0_combout\) # (!\r1_reg|dffs[3]~17\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100101001101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(4),
	datab => \r1add|auto_generated|_~0_combout\,
	datad => VCC,
	cin => \r1_reg|dffs[3]~17\,
	combout => \r1_reg|dffs[4]~18_combout\,
	cout => \r1_reg|dffs[4]~19\);

-- Location: LCCOMB_X74_Y66_N8
\Mux19~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux19~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & ((\r0_reg|dffs\(4)))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & (\mdr_reg|dffs\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \mdr_reg|dffs\(4),
	datac => \r0_reg|dffs\(4),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(14),
	combout => \Mux19~0_combout\);

-- Location: FF_X73_Y66_N17
\r1_reg|dffs[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r1_reg|dffs[4]~18_combout\,
	asdata => \Mux19~0_combout\,
	sclr => \r1_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(15),
	ena => \r1_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r1_reg|dffs\(4));

-- Location: LCCOMB_X74_Y67_N0
\r0add|auto_generated|_~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0add|auto_generated|_~0_combout\ = \r1_reg|dffs\(4) $ (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(18))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \r1_reg|dffs\(4),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	combout => \r0add|auto_generated|_~0_combout\);

-- Location: LCCOMB_X74_Y67_N16
\r0_reg|dffs[4]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0_reg|dffs[4]~18_combout\ = (\r0_reg|dffs\(4) & ((\r0add|auto_generated|_~0_combout\ & (!\r0_reg|dffs[3]~17\)) # (!\r0add|auto_generated|_~0_combout\ & (\r0_reg|dffs[3]~17\ & VCC)))) # (!\r0_reg|dffs\(4) & ((\r0add|auto_generated|_~0_combout\ & 
-- ((\r0_reg|dffs[3]~17\) # (GND))) # (!\r0add|auto_generated|_~0_combout\ & (!\r0_reg|dffs[3]~17\))))
-- \r0_reg|dffs[4]~19\ = CARRY((\r0_reg|dffs\(4) & (\r0add|auto_generated|_~0_combout\ & !\r0_reg|dffs[3]~17\)) # (!\r0_reg|dffs\(4) & ((\r0add|auto_generated|_~0_combout\) # (!\r0_reg|dffs[3]~17\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100101001101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(4),
	datab => \r0add|auto_generated|_~0_combout\,
	datad => VCC,
	cin => \r0_reg|dffs[3]~17\,
	combout => \r0_reg|dffs[4]~18_combout\,
	cout => \r0_reg|dffs[4]~19\);

-- Location: LCCOMB_X73_Y67_N6
\Mux11~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux11~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & ((\r1_reg|dffs\(4)))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & (\mdr_reg|dffs\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mdr_reg|dffs\(4),
	datac => \r1_reg|dffs\(4),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(16),
	combout => \Mux11~0_combout\);

-- Location: FF_X74_Y67_N17
\r0_reg|dffs[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r0_reg|dffs[4]~18_combout\,
	asdata => \Mux11~0_combout\,
	sclr => \r0_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(17),
	ena => \r0_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r0_reg|dffs\(4));

-- Location: LCCOMB_X74_Y67_N18
\r0_reg|dffs[5]~21\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0_reg|dffs[5]~21_combout\ = ((\r0add|auto_generated|_~5_combout\ $ (\r0_reg|dffs\(5) $ (\r0_reg|dffs[4]~19\)))) # (GND)
-- \r0_reg|dffs[5]~22\ = CARRY((\r0add|auto_generated|_~5_combout\ & (\r0_reg|dffs\(5) & !\r0_reg|dffs[4]~19\)) # (!\r0add|auto_generated|_~5_combout\ & ((\r0_reg|dffs\(5)) # (!\r0_reg|dffs[4]~19\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011001001101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \r0add|auto_generated|_~5_combout\,
	datab => \r0_reg|dffs\(5),
	datad => VCC,
	cin => \r0_reg|dffs[4]~19\,
	combout => \r0_reg|dffs[5]~21_combout\,
	cout => \r0_reg|dffs[5]~22\);

-- Location: LCCOMB_X75_Y67_N10
\Mux10~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux10~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & (\r1_reg|dffs\(5))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & ((\mdr_reg|dffs\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(5),
	datac => \mdr_reg|dffs\(5),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(16),
	combout => \Mux10~0_combout\);

-- Location: FF_X74_Y67_N19
\r0_reg|dffs[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r0_reg|dffs[5]~21_combout\,
	asdata => \Mux10~0_combout\,
	sclr => \r0_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(17),
	ena => \r0_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r0_reg|dffs\(5));

-- Location: LCCOMB_X73_Y66_N30
\r1add|auto_generated|_~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1add|auto_generated|_~5_combout\ = \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18) $ (\r0_reg|dffs\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	datad => \r0_reg|dffs\(5),
	combout => \r1add|auto_generated|_~5_combout\);

-- Location: LCCOMB_X73_Y66_N18
\r1_reg|dffs[5]~21\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1_reg|dffs[5]~21_combout\ = ((\r1add|auto_generated|_~5_combout\ $ (\r1_reg|dffs\(5) $ (\r1_reg|dffs[4]~19\)))) # (GND)
-- \r1_reg|dffs[5]~22\ = CARRY((\r1add|auto_generated|_~5_combout\ & (\r1_reg|dffs\(5) & !\r1_reg|dffs[4]~19\)) # (!\r1add|auto_generated|_~5_combout\ & ((\r1_reg|dffs\(5)) # (!\r1_reg|dffs[4]~19\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011001001101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \r1add|auto_generated|_~5_combout\,
	datab => \r1_reg|dffs\(5),
	datad => VCC,
	cin => \r1_reg|dffs[4]~19\,
	combout => \r1_reg|dffs[5]~21_combout\,
	cout => \r1_reg|dffs[5]~22\);

-- Location: LCCOMB_X74_Y66_N24
\Mux18~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux18~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & (\r0_reg|dffs\(5))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & ((\mdr_reg|dffs\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(5),
	datac => \mdr_reg|dffs\(5),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(14),
	combout => \Mux18~0_combout\);

-- Location: FF_X73_Y66_N19
\r1_reg|dffs[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r1_reg|dffs[5]~21_combout\,
	asdata => \Mux18~0_combout\,
	sclr => \r1_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(15),
	ena => \r1_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r1_reg|dffs\(5));

-- Location: LCCOMB_X75_Y67_N4
\r0add|auto_generated|_~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0add|auto_generated|_~5_combout\ = \r1_reg|dffs\(5) $ (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(18))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(5),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	combout => \r0add|auto_generated|_~5_combout\);

-- Location: LCCOMB_X74_Y67_N20
\r0_reg|dffs[6]~23\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0_reg|dffs[6]~23_combout\ = (\r0add|auto_generated|_~6_combout\ & ((\r0_reg|dffs\(6) & (!\r0_reg|dffs[5]~22\)) # (!\r0_reg|dffs\(6) & ((\r0_reg|dffs[5]~22\) # (GND))))) # (!\r0add|auto_generated|_~6_combout\ & ((\r0_reg|dffs\(6) & (\r0_reg|dffs[5]~22\ & 
-- VCC)) # (!\r0_reg|dffs\(6) & (!\r0_reg|dffs[5]~22\))))
-- \r0_reg|dffs[6]~24\ = CARRY((\r0add|auto_generated|_~6_combout\ & ((!\r0_reg|dffs[5]~22\) # (!\r0_reg|dffs\(6)))) # (!\r0add|auto_generated|_~6_combout\ & (!\r0_reg|dffs\(6) & !\r0_reg|dffs[5]~22\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100100101011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \r0add|auto_generated|_~6_combout\,
	datab => \r0_reg|dffs\(6),
	datad => VCC,
	cin => \r0_reg|dffs[5]~22\,
	combout => \r0_reg|dffs[6]~23_combout\,
	cout => \r0_reg|dffs[6]~24\);

-- Location: LCCOMB_X74_Y67_N22
\r0_reg|dffs[7]~25\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0_reg|dffs[7]~25_combout\ = \r0_reg|dffs\(7) $ (\r0_reg|dffs[6]~24\ $ (\r0add|auto_generated|_~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100111100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \r0_reg|dffs\(7),
	datad => \r0add|auto_generated|_~7_combout\,
	cin => \r0_reg|dffs[6]~24\,
	combout => \r0_reg|dffs[7]~25_combout\);

-- Location: LCCOMB_X75_Y67_N30
\Mux8~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux8~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & ((\r1_reg|dffs\(7)))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & (\mdr_reg|dffs\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \mdr_reg|dffs\(7),
	datac => \r1_reg|dffs\(7),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(16),
	combout => \Mux8~0_combout\);

-- Location: FF_X74_Y67_N23
\r0_reg|dffs[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r0_reg|dffs[7]~25_combout\,
	asdata => \Mux8~0_combout\,
	sclr => \r0_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(17),
	ena => \r0_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r0_reg|dffs\(7));

-- Location: LCCOMB_X74_Y66_N6
\r1add|auto_generated|_~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1add|auto_generated|_~7_combout\ = \r0_reg|dffs\(7) $ (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(18))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \r0_reg|dffs\(7),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	combout => \r1add|auto_generated|_~7_combout\);

-- Location: LCCOMB_X73_Y66_N20
\r1_reg|dffs[6]~23\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1_reg|dffs[6]~23_combout\ = (\r1add|auto_generated|_~6_combout\ & ((\r1_reg|dffs\(6) & (!\r1_reg|dffs[5]~22\)) # (!\r1_reg|dffs\(6) & ((\r1_reg|dffs[5]~22\) # (GND))))) # (!\r1add|auto_generated|_~6_combout\ & ((\r1_reg|dffs\(6) & (\r1_reg|dffs[5]~22\ & 
-- VCC)) # (!\r1_reg|dffs\(6) & (!\r1_reg|dffs[5]~22\))))
-- \r1_reg|dffs[6]~24\ = CARRY((\r1add|auto_generated|_~6_combout\ & ((!\r1_reg|dffs[5]~22\) # (!\r1_reg|dffs\(6)))) # (!\r1add|auto_generated|_~6_combout\ & (!\r1_reg|dffs\(6) & !\r1_reg|dffs[5]~22\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100100101011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \r1add|auto_generated|_~6_combout\,
	datab => \r1_reg|dffs\(6),
	datad => VCC,
	cin => \r1_reg|dffs[5]~22\,
	combout => \r1_reg|dffs[6]~23_combout\,
	cout => \r1_reg|dffs[6]~24\);

-- Location: LCCOMB_X73_Y66_N22
\r1_reg|dffs[7]~25\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1_reg|dffs[7]~25_combout\ = \r1_reg|dffs\(7) $ (\r1_reg|dffs[6]~24\ $ (\r1add|auto_generated|_~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010101011010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(7),
	datad => \r1add|auto_generated|_~7_combout\,
	cin => \r1_reg|dffs[6]~24\,
	combout => \r1_reg|dffs[7]~25_combout\);

-- Location: LCCOMB_X74_Y66_N28
\Mux16~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux16~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & (\r0_reg|dffs\(7))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & ((\mdr_reg|dffs\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \r0_reg|dffs\(7),
	datac => \mdr_reg|dffs\(7),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(14),
	combout => \Mux16~0_combout\);

-- Location: FF_X73_Y66_N23
\r1_reg|dffs[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r1_reg|dffs[7]~25_combout\,
	asdata => \Mux16~0_combout\,
	sclr => \r1_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(15),
	ena => \r1_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r1_reg|dffs\(7));

-- Location: LCCOMB_X75_Y67_N2
\mdr_reg|dffs[7]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \mdr_reg|dffs[7]~7_combout\ = (\ir_reg|dffs\(0) & (\r1_reg|dffs\(7))) # (!\ir_reg|dffs\(0) & ((\r0_reg|dffs\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(7),
	datab => \r0_reg|dffs\(7),
	datad => \ir_reg|dffs\(0),
	combout => \mdr_reg|dffs[7]~7_combout\);

-- Location: FF_X75_Y67_N3
\mdr_reg|dffs[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mdr_reg|dffs[7]~7_combout\,
	asdata => \Ram|sram|ram_block|auto_generated|q_a\(7),
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(27),
	ena => \ctrlSignals~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mdr_reg|dffs\(7));

-- Location: LCCOMB_X75_Y66_N30
\ir_reg|dffs[7]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \ir_reg|dffs[7]~feeder_combout\ = \mdr_reg|dffs\(7)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \mdr_reg|dffs\(7),
	combout => \ir_reg|dffs[7]~feeder_combout\);

-- Location: FF_X75_Y66_N31
\ir_reg|dffs[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \ir_reg|dffs[7]~feeder_combout\,
	ena => \ctrlSignals~13_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \ir_reg|dffs\(7));

-- Location: LCCOMB_X79_Y66_N22
\usequencer|uPC_mux|auto_generated|result_node[7]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \usequencer|uPC_mux|auto_generated|result_node[7]~7_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(8) & ((\ir_reg|dffs\(7)))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(8) & 
-- (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(7),
	datab => \ir_reg|dffs\(7),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(8),
	combout => \usequencer|uPC_mux|auto_generated|result_node[7]~7_combout\);

-- Location: IOIBUF_X87_Y73_N8
\clear~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clear,
	o => \clear~input_o\);

-- Location: FF_X79_Y66_N23
\usequencer|uPC|dffs[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \usequencer|uPC_mux|auto_generated|result_node[7]~7_combout\,
	sclr => \clear~input_o\,
	ena => \delay|auto_generated|counter_comb_bita1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \usequencer|uPC|dffs\(7));

-- Location: LCCOMB_X74_Y67_N30
\r0add|auto_generated|_~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0add|auto_generated|_~6_combout\ = \r1_reg|dffs\(6) $ (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(18))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \r1_reg|dffs\(6),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	combout => \r0add|auto_generated|_~6_combout\);

-- Location: LCCOMB_X75_Y67_N20
\Mux9~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux9~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & (\r1_reg|dffs\(6))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(16) & ((\mdr_reg|dffs\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(6),
	datab => \mdr_reg|dffs\(6),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(16),
	combout => \Mux9~0_combout\);

-- Location: FF_X74_Y67_N21
\r0_reg|dffs[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r0_reg|dffs[6]~23_combout\,
	asdata => \Mux9~0_combout\,
	sclr => \r0_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(17),
	ena => \r0_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r0_reg|dffs\(6));

-- Location: LCCOMB_X74_Y66_N2
\r1add|auto_generated|_~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1add|auto_generated|_~6_combout\ = \r0_reg|dffs\(6) $ (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(18))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(6),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	combout => \r1add|auto_generated|_~6_combout\);

-- Location: LCCOMB_X74_Y66_N12
\Mux17~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux17~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & (\r0_reg|dffs\(6))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(14) & ((\mdr_reg|dffs\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(6),
	datac => \mdr_reg|dffs\(6),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(14),
	combout => \Mux17~0_combout\);

-- Location: FF_X73_Y66_N21
\r1_reg|dffs[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \r1_reg|dffs[6]~23_combout\,
	asdata => \Mux17~0_combout\,
	sclr => \r1_reg|dffs[7]~20_combout\,
	sload => \usequencer|uROM|srom|rom_block|auto_generated|ALT_INV_q_a\(15),
	ena => \r1_enable~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \r1_reg|dffs\(6));

-- Location: LCCOMB_X75_Y67_N24
\mdr_reg|dffs[6]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \mdr_reg|dffs[6]~6_combout\ = (\ir_reg|dffs\(0) & (\r1_reg|dffs\(6))) # (!\ir_reg|dffs\(0) & ((\r0_reg|dffs\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(6),
	datab => \r0_reg|dffs\(6),
	datad => \ir_reg|dffs\(0),
	combout => \mdr_reg|dffs[6]~6_combout\);

-- Location: FF_X75_Y67_N25
\mdr_reg|dffs[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \mdr_reg|dffs[6]~6_combout\,
	asdata => \Ram|sram|ram_block|auto_generated|q_a\(6),
	sload => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(27),
	ena => \ctrlSignals~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \mdr_reg|dffs\(6));

-- Location: FF_X75_Y66_N17
\ir_reg|dffs[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \mdr_reg|dffs\(6),
	sload => VCC,
	ena => \ctrlSignals~13_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \ir_reg|dffs\(6));

-- Location: LCCOMB_X79_Y66_N24
\usequencer|uPC_mux|auto_generated|result_node[6]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \usequencer|uPC_mux|auto_generated|result_node[6]~6_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(8) & (\ir_reg|dffs\(6))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(8) & 
-- ((\usequencer|uROM|srom|rom_block|auto_generated|q_a\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \ir_reg|dffs\(6),
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(6),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(8),
	combout => \usequencer|uPC_mux|auto_generated|result_node[6]~6_combout\);

-- Location: FF_X79_Y66_N25
\usequencer|uPC|dffs[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \usequencer|uPC_mux|auto_generated|result_node[6]~6_combout\,
	sclr => \clear~input_o\,
	ena => \delay|auto_generated|counter_comb_bita1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \usequencer|uPC|dffs\(6));

-- Location: FF_X75_Y66_N27
\ir_reg|dffs[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \mdr_reg|dffs\(5),
	sload => VCC,
	ena => \ctrlSignals~13_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \ir_reg|dffs\(5));

-- Location: LCCOMB_X79_Y66_N6
\usequencer|uPC_mux|auto_generated|result_node[5]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \usequencer|uPC_mux|auto_generated|result_node[5]~5_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(8) & ((\ir_reg|dffs\(5)))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(8) & 
-- (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(5),
	datab => \ir_reg|dffs\(5),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(8),
	combout => \usequencer|uPC_mux|auto_generated|result_node[5]~5_combout\);

-- Location: FF_X79_Y66_N7
\usequencer|uPC|dffs[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \usequencer|uPC_mux|auto_generated|result_node[5]~5_combout\,
	sclr => \clear~input_o\,
	ena => \delay|auto_generated|counter_comb_bita1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \usequencer|uPC|dffs\(5));

-- Location: FF_X75_Y66_N23
\ir_reg|dffs[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \mdr_reg|dffs\(4),
	sload => VCC,
	ena => \ctrlSignals~13_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \ir_reg|dffs\(4));

-- Location: LCCOMB_X79_Y66_N12
\usequencer|uPC_mux|auto_generated|result_node[4]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \usequencer|uPC_mux|auto_generated|result_node[4]~4_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(8) & ((\ir_reg|dffs\(4)))) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(8) & 
-- (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(4),
	datac => \ir_reg|dffs\(4),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(8),
	combout => \usequencer|uPC_mux|auto_generated|result_node[4]~4_combout\);

-- Location: FF_X79_Y66_N13
\usequencer|uPC|dffs[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \usequencer|uPC_mux|auto_generated|result_node[4]~4_combout\,
	sclr => \clear~input_o\,
	ena => \delay|auto_generated|counter_comb_bita1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \usequencer|uPC|dffs\(4));

-- Location: LCCOMB_X79_Y66_N26
\usequencer|uPC_mux|auto_generated|result_node[3]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \usequencer|uPC_mux|auto_generated|result_node[3]~3_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(3) & !\usequencer|uROM|srom|rom_block|auto_generated|q_a\(8))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(3),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(8),
	combout => \usequencer|uPC_mux|auto_generated|result_node[3]~3_combout\);

-- Location: FF_X79_Y66_N27
\usequencer|uPC|dffs[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \usequencer|uPC_mux|auto_generated|result_node[3]~3_combout\,
	sclr => \clear~input_o\,
	ena => \delay|auto_generated|counter_comb_bita1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \usequencer|uPC|dffs\(3));

-- Location: LCCOMB_X79_Y66_N4
\usequencer|uPC_mux|auto_generated|result_node[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \usequencer|uPC_mux|auto_generated|result_node[2]~2_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(2) & !\usequencer|uROM|srom|rom_block|auto_generated|q_a\(8))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(2),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(8),
	combout => \usequencer|uPC_mux|auto_generated|result_node[2]~2_combout\);

-- Location: FF_X79_Y66_N5
\usequencer|uPC|dffs[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \usequencer|uPC_mux|auto_generated|result_node[2]~2_combout\,
	sclr => \clear~input_o\,
	ena => \delay|auto_generated|counter_comb_bita1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \usequencer|uPC|dffs\(2));

-- Location: LCCOMB_X79_Y66_N2
\usequencer|uPC_mux|auto_generated|result_node[1]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \usequencer|uPC_mux|auto_generated|result_node[1]~1_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(1) & !\usequencer|uROM|srom|rom_block|auto_generated|q_a\(8))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(1),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(8),
	combout => \usequencer|uPC_mux|auto_generated|result_node[1]~1_combout\);

-- Location: FF_X79_Y66_N3
\usequencer|uPC|dffs[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \usequencer|uPC_mux|auto_generated|result_node[1]~1_combout\,
	sclr => \clear~input_o\,
	ena => \delay|auto_generated|counter_comb_bita1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \usequencer|uPC|dffs\(1));

-- Location: LCCOMB_X79_Y66_N28
\usequencer|uPC_mux|auto_generated|result_node[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \usequencer|uPC_mux|auto_generated|result_node[0]~0_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(0) & !\usequencer|uROM|srom|rom_block|auto_generated|q_a\(8))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(0),
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(8),
	combout => \usequencer|uPC_mux|auto_generated|result_node[0]~0_combout\);

-- Location: FF_X79_Y66_N29
\usequencer|uPC|dffs[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \usequencer|uPC_mux|auto_generated|result_node[0]~0_combout\,
	sclr => \clear~input_o\,
	ena => \delay|auto_generated|counter_comb_bita1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \usequencer|uPC|dffs\(0));

-- Location: LCCOMB_X76_Y66_N6
\pc_counter|auto_generated|counter_reg_bit[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pc_counter|auto_generated|counter_reg_bit[0]~0_combout\ = (\mdr_reg|dffs\(0) & ((!\delay|auto_generated|counter_comb_bita1~0_combout\) # (!\usequencer|uROM|srom|rom_block|auto_generated|q_a\(31))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(31),
	datac => \mdr_reg|dffs\(0),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \pc_counter|auto_generated|counter_reg_bit[0]~0_combout\);

-- Location: FF_X76_Y66_N13
\pc_counter|auto_generated|counter_reg_bit[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \pc_counter|auto_generated|counter_comb_bita0~combout\,
	asdata => \pc_counter|auto_generated|counter_reg_bit[0]~0_combout\,
	sload => \pc_counter|auto_generated|counter_reg_bit[7]~2_combout\,
	ena => \pc_counter|auto_generated|_~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \pc_counter|auto_generated|counter_reg_bit\(0));

-- Location: LCCOMB_X79_Y67_N8
\pcseg_0|Mux6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pcseg_0|Mux6~0_combout\ = (\pc_counter|auto_generated|counter_reg_bit\(0) & ((\pc_counter|auto_generated|counter_reg_bit\(3)) # (\pc_counter|auto_generated|counter_reg_bit\(2) $ (\pc_counter|auto_generated|counter_reg_bit\(1))))) # 
-- (!\pc_counter|auto_generated|counter_reg_bit\(0) & ((\pc_counter|auto_generated|counter_reg_bit\(1)) # (\pc_counter|auto_generated|counter_reg_bit\(2) $ (\pc_counter|auto_generated|counter_reg_bit\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011110111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(0),
	datab => \pc_counter|auto_generated|counter_reg_bit\(2),
	datac => \pc_counter|auto_generated|counter_reg_bit\(3),
	datad => \pc_counter|auto_generated|counter_reg_bit\(1),
	combout => \pcseg_0|Mux6~0_combout\);

-- Location: LCCOMB_X79_Y67_N22
\pcseg_0|Mux5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pcseg_0|Mux5~0_combout\ = (\pc_counter|auto_generated|counter_reg_bit\(0) & (\pc_counter|auto_generated|counter_reg_bit\(3) $ (((\pc_counter|auto_generated|counter_reg_bit\(1)) # (!\pc_counter|auto_generated|counter_reg_bit\(2)))))) # 
-- (!\pc_counter|auto_generated|counter_reg_bit\(0) & (!\pc_counter|auto_generated|counter_reg_bit\(2) & (!\pc_counter|auto_generated|counter_reg_bit\(3) & \pc_counter|auto_generated|counter_reg_bit\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101110000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(0),
	datab => \pc_counter|auto_generated|counter_reg_bit\(2),
	datac => \pc_counter|auto_generated|counter_reg_bit\(3),
	datad => \pc_counter|auto_generated|counter_reg_bit\(1),
	combout => \pcseg_0|Mux5~0_combout\);

-- Location: LCCOMB_X79_Y67_N4
\pcseg_0|Mux4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pcseg_0|Mux4~0_combout\ = (\pc_counter|auto_generated|counter_reg_bit\(1) & (\pc_counter|auto_generated|counter_reg_bit\(0) & ((!\pc_counter|auto_generated|counter_reg_bit\(3))))) # (!\pc_counter|auto_generated|counter_reg_bit\(1) & 
-- ((\pc_counter|auto_generated|counter_reg_bit\(2) & ((!\pc_counter|auto_generated|counter_reg_bit\(3)))) # (!\pc_counter|auto_generated|counter_reg_bit\(2) & (\pc_counter|auto_generated|counter_reg_bit\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(0),
	datab => \pc_counter|auto_generated|counter_reg_bit\(2),
	datac => \pc_counter|auto_generated|counter_reg_bit\(3),
	datad => \pc_counter|auto_generated|counter_reg_bit\(1),
	combout => \pcseg_0|Mux4~0_combout\);

-- Location: LCCOMB_X79_Y67_N2
\pcseg_0|Mux3~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pcseg_0|Mux3~0_combout\ = (\pc_counter|auto_generated|counter_reg_bit\(1) & ((\pc_counter|auto_generated|counter_reg_bit\(0) & (\pc_counter|auto_generated|counter_reg_bit\(2))) # (!\pc_counter|auto_generated|counter_reg_bit\(0) & 
-- (!\pc_counter|auto_generated|counter_reg_bit\(2) & \pc_counter|auto_generated|counter_reg_bit\(3))))) # (!\pc_counter|auto_generated|counter_reg_bit\(1) & (!\pc_counter|auto_generated|counter_reg_bit\(3) & (\pc_counter|auto_generated|counter_reg_bit\(0) $ 
-- (\pc_counter|auto_generated|counter_reg_bit\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001100000000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(0),
	datab => \pc_counter|auto_generated|counter_reg_bit\(2),
	datac => \pc_counter|auto_generated|counter_reg_bit\(3),
	datad => \pc_counter|auto_generated|counter_reg_bit\(1),
	combout => \pcseg_0|Mux3~0_combout\);

-- Location: LCCOMB_X79_Y67_N24
\pcseg_0|Mux2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pcseg_0|Mux2~0_combout\ = (\pc_counter|auto_generated|counter_reg_bit\(2) & (\pc_counter|auto_generated|counter_reg_bit\(3) & ((\pc_counter|auto_generated|counter_reg_bit\(1)) # (!\pc_counter|auto_generated|counter_reg_bit\(0))))) # 
-- (!\pc_counter|auto_generated|counter_reg_bit\(2) & (!\pc_counter|auto_generated|counter_reg_bit\(0) & (!\pc_counter|auto_generated|counter_reg_bit\(3) & \pc_counter|auto_generated|counter_reg_bit\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000101000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(0),
	datab => \pc_counter|auto_generated|counter_reg_bit\(2),
	datac => \pc_counter|auto_generated|counter_reg_bit\(3),
	datad => \pc_counter|auto_generated|counter_reg_bit\(1),
	combout => \pcseg_0|Mux2~0_combout\);

-- Location: LCCOMB_X76_Y67_N4
\pcseg_0|Mux1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pcseg_0|Mux1~0_combout\ = (\pc_counter|auto_generated|counter_reg_bit\(1) & ((\pc_counter|auto_generated|counter_reg_bit\(0) & ((\pc_counter|auto_generated|counter_reg_bit\(3)))) # (!\pc_counter|auto_generated|counter_reg_bit\(0) & 
-- (\pc_counter|auto_generated|counter_reg_bit\(2))))) # (!\pc_counter|auto_generated|counter_reg_bit\(1) & (\pc_counter|auto_generated|counter_reg_bit\(2) & (\pc_counter|auto_generated|counter_reg_bit\(0) $ 
-- (\pc_counter|auto_generated|counter_reg_bit\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110010001001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(0),
	datab => \pc_counter|auto_generated|counter_reg_bit\(2),
	datac => \pc_counter|auto_generated|counter_reg_bit\(1),
	datad => \pc_counter|auto_generated|counter_reg_bit\(3),
	combout => \pcseg_0|Mux1~0_combout\);

-- Location: LCCOMB_X79_Y67_N26
\pcseg_0|Mux0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pcseg_0|Mux0~0_combout\ = (\pc_counter|auto_generated|counter_reg_bit\(2) & (!\pc_counter|auto_generated|counter_reg_bit\(1) & (\pc_counter|auto_generated|counter_reg_bit\(0) $ (!\pc_counter|auto_generated|counter_reg_bit\(3))))) # 
-- (!\pc_counter|auto_generated|counter_reg_bit\(2) & (\pc_counter|auto_generated|counter_reg_bit\(0) & (\pc_counter|auto_generated|counter_reg_bit\(3) $ (!\pc_counter|auto_generated|counter_reg_bit\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000010000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(0),
	datab => \pc_counter|auto_generated|counter_reg_bit\(2),
	datac => \pc_counter|auto_generated|counter_reg_bit\(3),
	datad => \pc_counter|auto_generated|counter_reg_bit\(1),
	combout => \pcseg_0|Mux0~0_combout\);

-- Location: LCCOMB_X49_Y70_N0
\pcseg_1|Mux6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pcseg_1|Mux6~0_combout\ = (\pc_counter|auto_generated|counter_reg_bit\(4) & ((\pc_counter|auto_generated|counter_reg_bit\(7)) # (\pc_counter|auto_generated|counter_reg_bit\(5) $ (\pc_counter|auto_generated|counter_reg_bit\(6))))) # 
-- (!\pc_counter|auto_generated|counter_reg_bit\(4) & ((\pc_counter|auto_generated|counter_reg_bit\(5)) # (\pc_counter|auto_generated|counter_reg_bit\(7) $ (\pc_counter|auto_generated|counter_reg_bit\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110011111111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(4),
	datab => \pc_counter|auto_generated|counter_reg_bit\(5),
	datac => \pc_counter|auto_generated|counter_reg_bit\(7),
	datad => \pc_counter|auto_generated|counter_reg_bit\(6),
	combout => \pcseg_1|Mux6~0_combout\);

-- Location: LCCOMB_X49_Y70_N2
\pcseg_1|Mux5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pcseg_1|Mux5~0_combout\ = (\pc_counter|auto_generated|counter_reg_bit\(4) & (\pc_counter|auto_generated|counter_reg_bit\(7) $ (((\pc_counter|auto_generated|counter_reg_bit\(5)) # (!\pc_counter|auto_generated|counter_reg_bit\(6)))))) # 
-- (!\pc_counter|auto_generated|counter_reg_bit\(4) & (\pc_counter|auto_generated|counter_reg_bit\(5) & (!\pc_counter|auto_generated|counter_reg_bit\(7) & !\pc_counter|auto_generated|counter_reg_bit\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010100000001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(4),
	datab => \pc_counter|auto_generated|counter_reg_bit\(5),
	datac => \pc_counter|auto_generated|counter_reg_bit\(7),
	datad => \pc_counter|auto_generated|counter_reg_bit\(6),
	combout => \pcseg_1|Mux5~0_combout\);

-- Location: LCCOMB_X49_Y70_N28
\pcseg_1|Mux4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pcseg_1|Mux4~0_combout\ = (\pc_counter|auto_generated|counter_reg_bit\(5) & (\pc_counter|auto_generated|counter_reg_bit\(4) & (!\pc_counter|auto_generated|counter_reg_bit\(7)))) # (!\pc_counter|auto_generated|counter_reg_bit\(5) & 
-- ((\pc_counter|auto_generated|counter_reg_bit\(6) & ((!\pc_counter|auto_generated|counter_reg_bit\(7)))) # (!\pc_counter|auto_generated|counter_reg_bit\(6) & (\pc_counter|auto_generated|counter_reg_bit\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101100101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(4),
	datab => \pc_counter|auto_generated|counter_reg_bit\(5),
	datac => \pc_counter|auto_generated|counter_reg_bit\(7),
	datad => \pc_counter|auto_generated|counter_reg_bit\(6),
	combout => \pcseg_1|Mux4~0_combout\);

-- Location: LCCOMB_X49_Y70_N22
\pcseg_1|Mux3~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pcseg_1|Mux3~0_combout\ = (\pc_counter|auto_generated|counter_reg_bit\(5) & ((\pc_counter|auto_generated|counter_reg_bit\(4) & ((\pc_counter|auto_generated|counter_reg_bit\(6)))) # (!\pc_counter|auto_generated|counter_reg_bit\(4) & 
-- (\pc_counter|auto_generated|counter_reg_bit\(7) & !\pc_counter|auto_generated|counter_reg_bit\(6))))) # (!\pc_counter|auto_generated|counter_reg_bit\(5) & (!\pc_counter|auto_generated|counter_reg_bit\(7) & (\pc_counter|auto_generated|counter_reg_bit\(4) $ 
-- (\pc_counter|auto_generated|counter_reg_bit\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100101000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(4),
	datab => \pc_counter|auto_generated|counter_reg_bit\(5),
	datac => \pc_counter|auto_generated|counter_reg_bit\(7),
	datad => \pc_counter|auto_generated|counter_reg_bit\(6),
	combout => \pcseg_1|Mux3~0_combout\);

-- Location: LCCOMB_X76_Y67_N22
\pcseg_1|Mux2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pcseg_1|Mux2~0_combout\ = (\pc_counter|auto_generated|counter_reg_bit\(6) & (\pc_counter|auto_generated|counter_reg_bit\(7) & ((\pc_counter|auto_generated|counter_reg_bit\(5)) # (!\pc_counter|auto_generated|counter_reg_bit\(4))))) # 
-- (!\pc_counter|auto_generated|counter_reg_bit\(6) & (\pc_counter|auto_generated|counter_reg_bit\(5) & (!\pc_counter|auto_generated|counter_reg_bit\(7) & !\pc_counter|auto_generated|counter_reg_bit\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000010100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(6),
	datab => \pc_counter|auto_generated|counter_reg_bit\(5),
	datac => \pc_counter|auto_generated|counter_reg_bit\(7),
	datad => \pc_counter|auto_generated|counter_reg_bit\(4),
	combout => \pcseg_1|Mux2~0_combout\);

-- Location: LCCOMB_X49_Y70_N12
\pcseg_1|Mux1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pcseg_1|Mux1~0_combout\ = (\pc_counter|auto_generated|counter_reg_bit\(5) & ((\pc_counter|auto_generated|counter_reg_bit\(4) & (\pc_counter|auto_generated|counter_reg_bit\(7))) # (!\pc_counter|auto_generated|counter_reg_bit\(4) & 
-- ((\pc_counter|auto_generated|counter_reg_bit\(6)))))) # (!\pc_counter|auto_generated|counter_reg_bit\(5) & (\pc_counter|auto_generated|counter_reg_bit\(6) & (\pc_counter|auto_generated|counter_reg_bit\(4) $ 
-- (\pc_counter|auto_generated|counter_reg_bit\(7)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101011010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(4),
	datab => \pc_counter|auto_generated|counter_reg_bit\(5),
	datac => \pc_counter|auto_generated|counter_reg_bit\(7),
	datad => \pc_counter|auto_generated|counter_reg_bit\(6),
	combout => \pcseg_1|Mux1~0_combout\);

-- Location: LCCOMB_X49_Y70_N26
\pcseg_1|Mux0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \pcseg_1|Mux0~0_combout\ = (\pc_counter|auto_generated|counter_reg_bit\(7) & (\pc_counter|auto_generated|counter_reg_bit\(4) & (\pc_counter|auto_generated|counter_reg_bit\(5) $ (\pc_counter|auto_generated|counter_reg_bit\(6))))) # 
-- (!\pc_counter|auto_generated|counter_reg_bit\(7) & (!\pc_counter|auto_generated|counter_reg_bit\(5) & (\pc_counter|auto_generated|counter_reg_bit\(4) $ (\pc_counter|auto_generated|counter_reg_bit\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000110000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \pc_counter|auto_generated|counter_reg_bit\(4),
	datab => \pc_counter|auto_generated|counter_reg_bit\(5),
	datac => \pc_counter|auto_generated|counter_reg_bit\(7),
	datad => \pc_counter|auto_generated|counter_reg_bit\(6),
	combout => \pcseg_1|Mux0~0_combout\);

-- Location: LCCOMB_X75_Y69_N0
\r0seg_1|Mux6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0seg_1|Mux6~0_combout\ = (\r0_reg|dffs\(4) & ((\r0_reg|dffs\(7)) # (\r0_reg|dffs\(5) $ (\r0_reg|dffs\(6))))) # (!\r0_reg|dffs\(4) & ((\r0_reg|dffs\(5)) # (\r0_reg|dffs\(7) $ (\r0_reg|dffs\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101111010111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(5),
	datab => \r0_reg|dffs\(7),
	datac => \r0_reg|dffs\(6),
	datad => \r0_reg|dffs\(4),
	combout => \r0seg_1|Mux6~0_combout\);

-- Location: LCCOMB_X75_Y69_N22
\r0seg_1|Mux5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0seg_1|Mux5~0_combout\ = (\r0_reg|dffs\(5) & (!\r0_reg|dffs\(7) & ((\r0_reg|dffs\(4)) # (!\r0_reg|dffs\(6))))) # (!\r0_reg|dffs\(5) & (\r0_reg|dffs\(4) & (\r0_reg|dffs\(7) $ (!\r0_reg|dffs\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110001100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(5),
	datab => \r0_reg|dffs\(7),
	datac => \r0_reg|dffs\(6),
	datad => \r0_reg|dffs\(4),
	combout => \r0seg_1|Mux5~0_combout\);

-- Location: LCCOMB_X75_Y69_N8
\r0seg_1|Mux4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0seg_1|Mux4~0_combout\ = (\r0_reg|dffs\(5) & (!\r0_reg|dffs\(7) & ((\r0_reg|dffs\(4))))) # (!\r0_reg|dffs\(5) & ((\r0_reg|dffs\(6) & (!\r0_reg|dffs\(7))) # (!\r0_reg|dffs\(6) & ((\r0_reg|dffs\(4))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011011100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(5),
	datab => \r0_reg|dffs\(7),
	datac => \r0_reg|dffs\(6),
	datad => \r0_reg|dffs\(4),
	combout => \r0seg_1|Mux4~0_combout\);

-- Location: LCCOMB_X75_Y69_N30
\r0seg_1|Mux3~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0seg_1|Mux3~0_combout\ = (\r0_reg|dffs\(5) & ((\r0_reg|dffs\(6) & ((\r0_reg|dffs\(4)))) # (!\r0_reg|dffs\(6) & (\r0_reg|dffs\(7) & !\r0_reg|dffs\(4))))) # (!\r0_reg|dffs\(5) & (!\r0_reg|dffs\(7) & (\r0_reg|dffs\(6) $ (\r0_reg|dffs\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000100011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(5),
	datab => \r0_reg|dffs\(7),
	datac => \r0_reg|dffs\(6),
	datad => \r0_reg|dffs\(4),
	combout => \r0seg_1|Mux3~0_combout\);

-- Location: LCCOMB_X75_Y69_N12
\r0seg_1|Mux2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0seg_1|Mux2~0_combout\ = (\r0_reg|dffs\(7) & (\r0_reg|dffs\(6) & ((\r0_reg|dffs\(5)) # (!\r0_reg|dffs\(4))))) # (!\r0_reg|dffs\(7) & (\r0_reg|dffs\(5) & (!\r0_reg|dffs\(6) & !\r0_reg|dffs\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(5),
	datab => \r0_reg|dffs\(7),
	datac => \r0_reg|dffs\(6),
	datad => \r0_reg|dffs\(4),
	combout => \r0seg_1|Mux2~0_combout\);

-- Location: LCCOMB_X74_Y69_N4
\r0seg_1|Mux1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0seg_1|Mux1~0_combout\ = (\r0_reg|dffs\(5) & ((\r0_reg|dffs\(4) & ((\r0_reg|dffs\(7)))) # (!\r0_reg|dffs\(4) & (\r0_reg|dffs\(6))))) # (!\r0_reg|dffs\(5) & (\r0_reg|dffs\(6) & (\r0_reg|dffs\(4) $ (\r0_reg|dffs\(7)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110010001001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(4),
	datab => \r0_reg|dffs\(6),
	datac => \r0_reg|dffs\(5),
	datad => \r0_reg|dffs\(7),
	combout => \r0seg_1|Mux1~0_combout\);

-- Location: LCCOMB_X75_Y69_N2
\r0seg_1|Mux0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0seg_1|Mux0~0_combout\ = (\r0_reg|dffs\(7) & (\r0_reg|dffs\(4) & (\r0_reg|dffs\(5) $ (\r0_reg|dffs\(6))))) # (!\r0_reg|dffs\(7) & (!\r0_reg|dffs\(5) & (\r0_reg|dffs\(6) $ (\r0_reg|dffs\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100100100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(5),
	datab => \r0_reg|dffs\(7),
	datac => \r0_reg|dffs\(6),
	datad => \r0_reg|dffs\(4),
	combout => \r0seg_1|Mux0~0_combout\);

-- Location: LCCOMB_X73_Y69_N0
\r0seg_0|Mux6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0seg_0|Mux6~0_combout\ = (\r0_reg|dffs\(0) & ((\r0_reg|dffs\(3)) # (\r0_reg|dffs\(2) $ (\r0_reg|dffs\(1))))) # (!\r0_reg|dffs\(0) & ((\r0_reg|dffs\(1)) # (\r0_reg|dffs\(2) $ (\r0_reg|dffs\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101111111100110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(2),
	datab => \r0_reg|dffs\(3),
	datac => \r0_reg|dffs\(0),
	datad => \r0_reg|dffs\(1),
	combout => \r0seg_0|Mux6~0_combout\);

-- Location: LCCOMB_X73_Y69_N2
\r0seg_0|Mux5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0seg_0|Mux5~0_combout\ = (\r0_reg|dffs\(2) & (\r0_reg|dffs\(0) & (\r0_reg|dffs\(3) $ (\r0_reg|dffs\(1))))) # (!\r0_reg|dffs\(2) & (!\r0_reg|dffs\(3) & ((\r0_reg|dffs\(0)) # (\r0_reg|dffs\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000110010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(2),
	datab => \r0_reg|dffs\(3),
	datac => \r0_reg|dffs\(0),
	datad => \r0_reg|dffs\(1),
	combout => \r0seg_0|Mux5~0_combout\);

-- Location: LCCOMB_X73_Y69_N24
\r0seg_0|Mux4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0seg_0|Mux4~0_combout\ = (\r0_reg|dffs\(1) & (((!\r0_reg|dffs\(3) & \r0_reg|dffs\(0))))) # (!\r0_reg|dffs\(1) & ((\r0_reg|dffs\(2) & (!\r0_reg|dffs\(3))) # (!\r0_reg|dffs\(2) & ((\r0_reg|dffs\(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000001110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(2),
	datab => \r0_reg|dffs\(3),
	datac => \r0_reg|dffs\(0),
	datad => \r0_reg|dffs\(1),
	combout => \r0seg_0|Mux4~0_combout\);

-- Location: LCCOMB_X73_Y69_N22
\r0seg_0|Mux3~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0seg_0|Mux3~0_combout\ = (\r0_reg|dffs\(1) & ((\r0_reg|dffs\(2) & ((\r0_reg|dffs\(0)))) # (!\r0_reg|dffs\(2) & (\r0_reg|dffs\(3) & !\r0_reg|dffs\(0))))) # (!\r0_reg|dffs\(1) & (!\r0_reg|dffs\(3) & (\r0_reg|dffs\(2) $ (\r0_reg|dffs\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010000010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(2),
	datab => \r0_reg|dffs\(3),
	datac => \r0_reg|dffs\(0),
	datad => \r0_reg|dffs\(1),
	combout => \r0seg_0|Mux3~0_combout\);

-- Location: LCCOMB_X73_Y69_N12
\r0seg_0|Mux2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0seg_0|Mux2~0_combout\ = (\r0_reg|dffs\(2) & (\r0_reg|dffs\(3) & ((\r0_reg|dffs\(1)) # (!\r0_reg|dffs\(0))))) # (!\r0_reg|dffs\(2) & (!\r0_reg|dffs\(3) & (!\r0_reg|dffs\(0) & \r0_reg|dffs\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100100001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(2),
	datab => \r0_reg|dffs\(3),
	datac => \r0_reg|dffs\(0),
	datad => \r0_reg|dffs\(1),
	combout => \r0seg_0|Mux2~0_combout\);

-- Location: LCCOMB_X73_Y69_N26
\r0seg_0|Mux1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0seg_0|Mux1~0_combout\ = (\r0_reg|dffs\(3) & ((\r0_reg|dffs\(0) & ((\r0_reg|dffs\(1)))) # (!\r0_reg|dffs\(0) & (\r0_reg|dffs\(2))))) # (!\r0_reg|dffs\(3) & (\r0_reg|dffs\(2) & (\r0_reg|dffs\(0) $ (\r0_reg|dffs\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(2),
	datab => \r0_reg|dffs\(3),
	datac => \r0_reg|dffs\(0),
	datad => \r0_reg|dffs\(1),
	combout => \r0seg_0|Mux1~0_combout\);

-- Location: LCCOMB_X73_Y69_N8
\r0seg_0|Mux0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r0seg_0|Mux0~0_combout\ = (\r0_reg|dffs\(2) & (!\r0_reg|dffs\(1) & (\r0_reg|dffs\(3) $ (!\r0_reg|dffs\(0))))) # (!\r0_reg|dffs\(2) & (\r0_reg|dffs\(0) & (\r0_reg|dffs\(3) $ (!\r0_reg|dffs\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000010010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r0_reg|dffs\(2),
	datab => \r0_reg|dffs\(3),
	datac => \r0_reg|dffs\(0),
	datad => \r0_reg|dffs\(1),
	combout => \r0seg_0|Mux0~0_combout\);

-- Location: LCCOMB_X73_Y67_N12
\r1seg_1|Mux6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1seg_1|Mux6~0_combout\ = (\r1_reg|dffs\(4) & ((\r1_reg|dffs\(7)) # (\r1_reg|dffs\(6) $ (\r1_reg|dffs\(5))))) # (!\r1_reg|dffs\(4) & ((\r1_reg|dffs\(5)) # (\r1_reg|dffs\(6) $ (\r1_reg|dffs\(7)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110101101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(6),
	datab => \r1_reg|dffs\(5),
	datac => \r1_reg|dffs\(4),
	datad => \r1_reg|dffs\(7),
	combout => \r1seg_1|Mux6~0_combout\);

-- Location: LCCOMB_X75_Y66_N28
\r1seg_1|Mux5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1seg_1|Mux5~0_combout\ = (\r1_reg|dffs\(6) & (\r1_reg|dffs\(4) & (\r1_reg|dffs\(7) $ (\r1_reg|dffs\(5))))) # (!\r1_reg|dffs\(6) & (!\r1_reg|dffs\(7) & ((\r1_reg|dffs\(5)) # (\r1_reg|dffs\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101100100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(7),
	datab => \r1_reg|dffs\(6),
	datac => \r1_reg|dffs\(5),
	datad => \r1_reg|dffs\(4),
	combout => \r1seg_1|Mux5~0_combout\);

-- Location: LCCOMB_X73_Y67_N30
\r1seg_1|Mux4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1seg_1|Mux4~0_combout\ = (\r1_reg|dffs\(5) & (((\r1_reg|dffs\(4) & !\r1_reg|dffs\(7))))) # (!\r1_reg|dffs\(5) & ((\r1_reg|dffs\(6) & ((!\r1_reg|dffs\(7)))) # (!\r1_reg|dffs\(6) & (\r1_reg|dffs\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000011110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(6),
	datab => \r1_reg|dffs\(5),
	datac => \r1_reg|dffs\(4),
	datad => \r1_reg|dffs\(7),
	combout => \r1seg_1|Mux4~0_combout\);

-- Location: LCCOMB_X74_Y66_N4
\r1seg_1|Mux3~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1seg_1|Mux3~0_combout\ = (\r1_reg|dffs\(5) & ((\r1_reg|dffs\(6) & (\r1_reg|dffs\(4))) # (!\r1_reg|dffs\(6) & (!\r1_reg|dffs\(4) & \r1_reg|dffs\(7))))) # (!\r1_reg|dffs\(5) & (!\r1_reg|dffs\(7) & (\r1_reg|dffs\(6) $ (\r1_reg|dffs\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001010010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(5),
	datab => \r1_reg|dffs\(6),
	datac => \r1_reg|dffs\(4),
	datad => \r1_reg|dffs\(7),
	combout => \r1seg_1|Mux3~0_combout\);

-- Location: LCCOMB_X73_Y67_N28
\r1seg_1|Mux2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1seg_1|Mux2~0_combout\ = (\r1_reg|dffs\(6) & (\r1_reg|dffs\(7) & ((\r1_reg|dffs\(5)) # (!\r1_reg|dffs\(4))))) # (!\r1_reg|dffs\(6) & (\r1_reg|dffs\(5) & (!\r1_reg|dffs\(4) & !\r1_reg|dffs\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(6),
	datab => \r1_reg|dffs\(5),
	datac => \r1_reg|dffs\(4),
	datad => \r1_reg|dffs\(7),
	combout => \r1seg_1|Mux2~0_combout\);

-- Location: LCCOMB_X73_Y67_N26
\r1seg_1|Mux1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1seg_1|Mux1~0_combout\ = (\r1_reg|dffs\(5) & ((\r1_reg|dffs\(4) & ((\r1_reg|dffs\(7)))) # (!\r1_reg|dffs\(4) & (\r1_reg|dffs\(6))))) # (!\r1_reg|dffs\(5) & (\r1_reg|dffs\(6) & (\r1_reg|dffs\(4) $ (\r1_reg|dffs\(7)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(6),
	datab => \r1_reg|dffs\(5),
	datac => \r1_reg|dffs\(4),
	datad => \r1_reg|dffs\(7),
	combout => \r1seg_1|Mux1~0_combout\);

-- Location: LCCOMB_X73_Y67_N8
\r1seg_1|Mux0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1seg_1|Mux0~0_combout\ = (\r1_reg|dffs\(6) & (!\r1_reg|dffs\(5) & (\r1_reg|dffs\(4) $ (!\r1_reg|dffs\(7))))) # (!\r1_reg|dffs\(6) & (\r1_reg|dffs\(4) & (\r1_reg|dffs\(5) $ (!\r1_reg|dffs\(7)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000000010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(6),
	datab => \r1_reg|dffs\(5),
	datac => \r1_reg|dffs\(4),
	datad => \r1_reg|dffs\(7),
	combout => \r1seg_1|Mux0~0_combout\);

-- Location: LCCOMB_X73_Y70_N16
\r1seg_0|Mux6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1seg_0|Mux6~0_combout\ = (\r1_reg|dffs\(0) & ((\r1_reg|dffs\(3)) # (\r1_reg|dffs\(2) $ (\r1_reg|dffs\(1))))) # (!\r1_reg|dffs\(0) & ((\r1_reg|dffs\(1)) # (\r1_reg|dffs\(2) $ (\r1_reg|dffs\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110101101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(2),
	datab => \r1_reg|dffs\(1),
	datac => \r1_reg|dffs\(0),
	datad => \r1_reg|dffs\(3),
	combout => \r1seg_0|Mux6~0_combout\);

-- Location: LCCOMB_X73_Y70_N18
\r1seg_0|Mux5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1seg_0|Mux5~0_combout\ = (\r1_reg|dffs\(2) & (\r1_reg|dffs\(0) & (\r1_reg|dffs\(1) $ (\r1_reg|dffs\(3))))) # (!\r1_reg|dffs\(2) & (!\r1_reg|dffs\(3) & ((\r1_reg|dffs\(1)) # (\r1_reg|dffs\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000011010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(2),
	datab => \r1_reg|dffs\(1),
	datac => \r1_reg|dffs\(0),
	datad => \r1_reg|dffs\(3),
	combout => \r1seg_0|Mux5~0_combout\);

-- Location: LCCOMB_X73_Y70_N4
\r1seg_0|Mux4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1seg_0|Mux4~0_combout\ = (\r1_reg|dffs\(1) & (((\r1_reg|dffs\(0) & !\r1_reg|dffs\(3))))) # (!\r1_reg|dffs\(1) & ((\r1_reg|dffs\(2) & ((!\r1_reg|dffs\(3)))) # (!\r1_reg|dffs\(2) & (\r1_reg|dffs\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000011110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(2),
	datab => \r1_reg|dffs\(1),
	datac => \r1_reg|dffs\(0),
	datad => \r1_reg|dffs\(3),
	combout => \r1seg_0|Mux4~0_combout\);

-- Location: LCCOMB_X73_Y70_N26
\r1seg_0|Mux3~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1seg_0|Mux3~0_combout\ = (\r1_reg|dffs\(1) & ((\r1_reg|dffs\(2) & (\r1_reg|dffs\(0))) # (!\r1_reg|dffs\(2) & (!\r1_reg|dffs\(0) & \r1_reg|dffs\(3))))) # (!\r1_reg|dffs\(1) & (!\r1_reg|dffs\(3) & (\r1_reg|dffs\(2) $ (\r1_reg|dffs\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000010010010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(2),
	datab => \r1_reg|dffs\(1),
	datac => \r1_reg|dffs\(0),
	datad => \r1_reg|dffs\(3),
	combout => \r1seg_0|Mux3~0_combout\);

-- Location: LCCOMB_X73_Y70_N0
\r1seg_0|Mux2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1seg_0|Mux2~0_combout\ = (\r1_reg|dffs\(2) & (\r1_reg|dffs\(3) & ((\r1_reg|dffs\(1)) # (!\r1_reg|dffs\(0))))) # (!\r1_reg|dffs\(2) & (\r1_reg|dffs\(1) & (!\r1_reg|dffs\(0) & !\r1_reg|dffs\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(2),
	datab => \r1_reg|dffs\(1),
	datac => \r1_reg|dffs\(0),
	datad => \r1_reg|dffs\(3),
	combout => \r1seg_0|Mux2~0_combout\);

-- Location: LCCOMB_X73_Y70_N10
\r1seg_0|Mux1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1seg_0|Mux1~0_combout\ = (\r1_reg|dffs\(1) & ((\r1_reg|dffs\(0) & ((\r1_reg|dffs\(3)))) # (!\r1_reg|dffs\(0) & (\r1_reg|dffs\(2))))) # (!\r1_reg|dffs\(1) & (\r1_reg|dffs\(2) & (\r1_reg|dffs\(0) $ (\r1_reg|dffs\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(2),
	datab => \r1_reg|dffs\(1),
	datac => \r1_reg|dffs\(0),
	datad => \r1_reg|dffs\(3),
	combout => \r1seg_0|Mux1~0_combout\);

-- Location: LCCOMB_X73_Y70_N12
\r1seg_0|Mux0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \r1seg_0|Mux0~0_combout\ = (\r1_reg|dffs\(2) & (!\r1_reg|dffs\(1) & (\r1_reg|dffs\(0) $ (!\r1_reg|dffs\(3))))) # (!\r1_reg|dffs\(2) & (\r1_reg|dffs\(0) & (\r1_reg|dffs\(1) $ (!\r1_reg|dffs\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000000010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1_reg|dffs\(2),
	datab => \r1_reg|dffs\(1),
	datac => \r1_reg|dffs\(0),
	datad => \r1_reg|dffs\(3),
	combout => \r1seg_0|Mux0~0_combout\);

-- Location: LCCOMB_X77_Y66_N6
\ctrlSignals~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~2_combout\ = (\delay|auto_generated|counter_comb_bita1~0_combout\ & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(11))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \delay|auto_generated|counter_comb_bita1~0_combout\,
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(11),
	combout => \ctrlSignals~2_combout\);

-- Location: LCCOMB_X79_Y66_N10
\ctrlSignals~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~3_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(12) & \delay|auto_generated|counter_comb_bita1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(12),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \ctrlSignals~3_combout\);

-- Location: LCCOMB_X73_Y70_N22
\ctrlSignals~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~4_combout\ = (\delay|auto_generated|counter_comb_bita1~0_combout\ & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(13))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \delay|auto_generated|counter_comb_bita1~0_combout\,
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(13),
	combout => \ctrlSignals~4_combout\);

-- Location: LCCOMB_X74_Y66_N22
\ctrlSignals~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~5_combout\ = (\delay|auto_generated|counter_comb_bita1~0_combout\ & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(14))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \delay|auto_generated|counter_comb_bita1~0_combout\,
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(14),
	combout => \ctrlSignals~5_combout\);

-- Location: LCCOMB_X72_Y66_N24
\ctrlSignals~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~6_combout\ = (\delay|auto_generated|counter_comb_bita1~0_combout\ & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(15))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \delay|auto_generated|counter_comb_bita1~0_combout\,
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(15),
	combout => \ctrlSignals~6_combout\);

-- Location: LCCOMB_X72_Y69_N28
\ctrlSignals~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~7_combout\ = (\delay|auto_generated|counter_comb_bita1~0_combout\ & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(16))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \delay|auto_generated|counter_comb_bita1~0_combout\,
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(16),
	combout => \ctrlSignals~7_combout\);

-- Location: LCCOMB_X72_Y69_N14
\ctrlSignals~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~8_combout\ = (\delay|auto_generated|counter_comb_bita1~0_combout\ & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(17))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \delay|auto_generated|counter_comb_bita1~0_combout\,
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(17),
	combout => \ctrlSignals~8_combout\);

-- Location: LCCOMB_X79_Y66_N16
\ctrlSignals~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~9_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(18) & \delay|auto_generated|counter_comb_bita1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(18),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \ctrlSignals~9_combout\);

-- Location: LCCOMB_X77_Y66_N28
\ctrlSignals~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~10_combout\ = (\delay|auto_generated|counter_comb_bita1~0_combout\ & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(19))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \delay|auto_generated|counter_comb_bita1~0_combout\,
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(19),
	combout => \ctrlSignals~10_combout\);

-- Location: LCCOMB_X77_Y66_N2
\ctrlSignals~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~11_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(20) & \delay|auto_generated|counter_comb_bita1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(20),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \ctrlSignals~11_combout\);

-- Location: LCCOMB_X81_Y69_N24
\ctrlSignals~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~15_combout\ = (\usequencer|uROM|srom|rom_block|auto_generated|q_a\(24) & \delay|auto_generated|counter_comb_bita1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(24),
	datad => \delay|auto_generated|counter_comb_bita1~0_combout\,
	combout => \ctrlSignals~15_combout\);

-- Location: LCCOMB_X83_Y69_N24
\ctrlSignals~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~16_combout\ = (\delay|auto_generated|counter_comb_bita1~0_combout\ & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(25))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \delay|auto_generated|counter_comb_bita1~0_combout\,
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(25),
	combout => \ctrlSignals~16_combout\);

-- Location: LCCOMB_X81_Y69_N2
\ctrlSignals~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~18_combout\ = (\delay|auto_generated|counter_comb_bita1~0_combout\ & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(27))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \delay|auto_generated|counter_comb_bita1~0_combout\,
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(27),
	combout => \ctrlSignals~18_combout\);

-- Location: LCCOMB_X72_Y66_N2
\ctrlSignals~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~20_combout\ = (\delay|auto_generated|counter_comb_bita1~0_combout\ & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(29))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \delay|auto_generated|counter_comb_bita1~0_combout\,
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(29),
	combout => \ctrlSignals~20_combout\);

-- Location: LCCOMB_X75_Y66_N20
\ctrlSignals~22\ : cycloneive_lcell_comb
-- Equation(s):
-- \ctrlSignals~22_combout\ = (\delay|auto_generated|counter_comb_bita1~0_combout\ & \usequencer|uROM|srom|rom_block|auto_generated|q_a\(31))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \delay|auto_generated|counter_comb_bita1~0_combout\,
	datad => \usequencer|uROM|srom|rom_block|auto_generated|q_a\(31),
	combout => \ctrlSignals~22_combout\);

-- Location: IOIBUF_X81_Y0_N15
\z~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_z,
	o => \z~input_o\);

ww_useqEnOut <= \useqEnOut~output_o\;

ww_pcSeg1(6) <= \pcSeg1[6]~output_o\;

ww_pcSeg1(5) <= \pcSeg1[5]~output_o\;

ww_pcSeg1(4) <= \pcSeg1[4]~output_o\;

ww_pcSeg1(3) <= \pcSeg1[3]~output_o\;

ww_pcSeg1(2) <= \pcSeg1[2]~output_o\;

ww_pcSeg1(1) <= \pcSeg1[1]~output_o\;

ww_pcSeg1(0) <= \pcSeg1[0]~output_o\;

ww_pcSeg2(6) <= \pcSeg2[6]~output_o\;

ww_pcSeg2(5) <= \pcSeg2[5]~output_o\;

ww_pcSeg2(4) <= \pcSeg2[4]~output_o\;

ww_pcSeg2(3) <= \pcSeg2[3]~output_o\;

ww_pcSeg2(2) <= \pcSeg2[2]~output_o\;

ww_pcSeg2(1) <= \pcSeg2[1]~output_o\;

ww_pcSeg2(0) <= \pcSeg2[0]~output_o\;

ww_r0SegHi(6) <= \r0SegHi[6]~output_o\;

ww_r0SegHi(5) <= \r0SegHi[5]~output_o\;

ww_r0SegHi(4) <= \r0SegHi[4]~output_o\;

ww_r0SegHi(3) <= \r0SegHi[3]~output_o\;

ww_r0SegHi(2) <= \r0SegHi[2]~output_o\;

ww_r0SegHi(1) <= \r0SegHi[1]~output_o\;

ww_r0SegHi(0) <= \r0SegHi[0]~output_o\;

ww_r0SegLo(6) <= \r0SegLo[6]~output_o\;

ww_r0SegLo(5) <= \r0SegLo[5]~output_o\;

ww_r0SegLo(4) <= \r0SegLo[4]~output_o\;

ww_r0SegLo(3) <= \r0SegLo[3]~output_o\;

ww_r0SegLo(2) <= \r0SegLo[2]~output_o\;

ww_r0SegLo(1) <= \r0SegLo[1]~output_o\;

ww_r0SegLo(0) <= \r0SegLo[0]~output_o\;

ww_r1SegHi(6) <= \r1SegHi[6]~output_o\;

ww_r1SegHi(5) <= \r1SegHi[5]~output_o\;

ww_r1SegHi(4) <= \r1SegHi[4]~output_o\;

ww_r1SegHi(3) <= \r1SegHi[3]~output_o\;

ww_r1SegHi(2) <= \r1SegHi[2]~output_o\;

ww_r1SegHi(1) <= \r1SegHi[1]~output_o\;

ww_r1SegHi(0) <= \r1SegHi[0]~output_o\;

ww_r1SegLo(6) <= \r1SegLo[6]~output_o\;

ww_r1SegLo(5) <= \r1SegLo[5]~output_o\;

ww_r1SegLo(4) <= \r1SegLo[4]~output_o\;

ww_r1SegLo(3) <= \r1SegLo[3]~output_o\;

ww_r1SegLo(2) <= \r1SegLo[2]~output_o\;

ww_r1SegLo(1) <= \r1SegLo[1]~output_o\;

ww_r1SegLo(0) <= \r1SegLo[0]~output_o\;

ww_spSeg1(6) <= \spSeg1[6]~output_o\;

ww_spSeg1(5) <= \spSeg1[5]~output_o\;

ww_spSeg1(4) <= \spSeg1[4]~output_o\;

ww_spSeg1(3) <= \spSeg1[3]~output_o\;

ww_spSeg1(2) <= \spSeg1[2]~output_o\;

ww_spSeg1(1) <= \spSeg1[1]~output_o\;

ww_spSeg1(0) <= \spSeg1[0]~output_o\;

ww_spSeg2(6) <= \spSeg2[6]~output_o\;

ww_spSeg2(5) <= \spSeg2[5]~output_o\;

ww_spSeg2(4) <= \spSeg2[4]~output_o\;

ww_spSeg2(3) <= \spSeg2[3]~output_o\;

ww_spSeg2(2) <= \spSeg2[2]~output_o\;

ww_spSeg2(1) <= \spSeg2[1]~output_o\;

ww_spSeg2(0) <= \spSeg2[0]~output_o\;

ww_ctrlSignals(22) <= \ctrlSignals[22]~output_o\;

ww_ctrlSignals(21) <= \ctrlSignals[21]~output_o\;

ww_ctrlSignals(20) <= \ctrlSignals[20]~output_o\;

ww_ctrlSignals(19) <= \ctrlSignals[19]~output_o\;

ww_ctrlSignals(18) <= \ctrlSignals[18]~output_o\;

ww_ctrlSignals(17) <= \ctrlSignals[17]~output_o\;

ww_ctrlSignals(16) <= \ctrlSignals[16]~output_o\;

ww_ctrlSignals(15) <= \ctrlSignals[15]~output_o\;

ww_ctrlSignals(14) <= \ctrlSignals[14]~output_o\;

ww_ctrlSignals(13) <= \ctrlSignals[13]~output_o\;

ww_ctrlSignals(12) <= \ctrlSignals[12]~output_o\;

ww_ctrlSignals(11) <= \ctrlSignals[11]~output_o\;

ww_ctrlSignals(10) <= \ctrlSignals[10]~output_o\;

ww_ctrlSignals(9) <= \ctrlSignals[9]~output_o\;

ww_ctrlSignals(8) <= \ctrlSignals[8]~output_o\;

ww_ctrlSignals(7) <= \ctrlSignals[7]~output_o\;

ww_ctrlSignals(6) <= \ctrlSignals[6]~output_o\;

ww_ctrlSignals(5) <= \ctrlSignals[5]~output_o\;

ww_ctrlSignals(4) <= \ctrlSignals[4]~output_o\;

ww_ctrlSignals(3) <= \ctrlSignals[3]~output_o\;

ww_ctrlSignals(2) <= \ctrlSignals[2]~output_o\;

ww_ctrlSignals(1) <= \ctrlSignals[1]~output_o\;

ww_ctrlSignals(0) <= \ctrlSignals[0]~output_o\;
END structure;


